package com.bank.controller;

import com.bank.dto.request.AccountRequest;
import com.bank.dto.response.AccountResponse;
import com.bank.dto.response.ApiResponse;
import com.bank.service.AccountService;
import com.bank.util.AppConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/*
   POST   /api/accounts                              → Create account
   GET    /api/accounts                              → Get all accounts
   GET    /api/accounts/{id}                         → Get account by MongoDB ID
   GET    /api/accounts/customer/{customerId}        → Get all accounts for a customer
   PUT    /api/accounts/{id}                         → Update account
   DELETE /api/accounts/{id}                         → Delete account
 */

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/accounts")
@Tag(name = "Account Management", description = "APIs for managing bank accounts")
public class AccountController {

    private final AccountService accountService;

    
    // POST /api/accounts
    
    @PostMapping
    @Operation(
        summary = "Create a new bank account",
        description = "Creates a new account for an existing customer. " +
                      "Account number is auto-generated. Balance starts at zero."
    )
    public ResponseEntity<ApiResponse<AccountResponse>> createAccount(
            @Valid @RequestBody AccountRequest request) {

        log.info("POST /api/accounts — type: {}, customer: {}",
                request.getAccountType(), request.getCustomerId());

        AccountResponse response = accountService.createAccount(request);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success(AppConstants.ACCOUNT_CREATED, response));
    }

    
    // GET /api/accounts
    
    @GetMapping
    @Operation(
        summary = "Get all accounts",
        description = "Returns all bank accounts in the system."
    )
    public ResponseEntity<ApiResponse<List<AccountResponse>>> getAllAccounts() {

        log.info("GET /api/accounts — fetching all accounts");

        List<AccountResponse> accounts = accountService.getAllAccounts();

        return ResponseEntity.ok(
                ApiResponse.success("Fetched " + accounts.size() + " account(s)", accounts));
    }

    
    // GET /api/accounts/{id}
    
    @GetMapping("/{id}")
    @Operation(
        summary = "Get account by ID",
        description = "Fetches a single account using its MongoDB ID."
    )
    public ResponseEntity<ApiResponse<AccountResponse>> getAccountById(
            @Parameter(description = "MongoDB ID of the account")
            @PathVariable String id) {

        log.info("GET /api/accounts/{}", id);

        return ResponseEntity.ok(
                ApiResponse.success("Account fetched successfully",
                        accountService.getAccountById(id)));
    }

   
    // GET /api/accounts/customer/{customerId}  ← ONE-TO-MANY ENDPOINT
    
    @GetMapping("/customer/{customerId}")
    @Operation(
        summary = "Get all accounts for a customer",
        description = "Returns all bank accounts belonging to a specific customer. " +
                      "This endpoint exposes the Customer → Account One-to-Many relationship."
    )
    public ResponseEntity<ApiResponse<List<AccountResponse>>> getAccountsByCustomer(
            @Parameter(description = "MongoDB ID of the customer")
            @PathVariable String customerId) {

        log.info("GET /api/accounts/customer/{} — fetching accounts", customerId);

        List<AccountResponse> accounts = accountService.getAccountsByCustomerId(customerId);

        return ResponseEntity.ok(
                ApiResponse.success(
                        "Fetched " + accounts.size() + " account(s) for customer",
                        accounts));
    }

    
    // PUT /api/accounts/{id}
    
    @PutMapping("/{id}")
    @Operation(
        summary = "Update an account",
        description = "Updates account details. Balance is NOT updated here — use Transaction APIs."
    )
    public ResponseEntity<ApiResponse<AccountResponse>> updateAccount(
            @Parameter(description = "MongoDB ID of the account to update")
            @PathVariable String id,
            @Valid @RequestBody AccountRequest request) {

        log.info("PUT /api/accounts/{}", id);

        return ResponseEntity.ok(
                ApiResponse.success(AppConstants.ACCOUNT_UPDATED,
                        accountService.updateAccount(id, request)));
    }

    
    // DELETE /api/accounts/{id}
    
    @DeleteMapping("/{id}")
    @Operation(
        summary = "Delete an account",
        description = "Deletes an account. Account balance must be zero before deletion."
    )
    public ResponseEntity<ApiResponse<Void>> deleteAccount(
            @Parameter(description = "MongoDB ID of the account to delete")
            @PathVariable String id) {

        log.info("DELETE /api/accounts/{}", id);

        accountService.deleteAccount(id);

        return ResponseEntity.ok(
                ApiResponse.success(AppConstants.ACCOUNT_DELETED));
    }
}
