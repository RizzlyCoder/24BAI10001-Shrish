package com.bank.repository;

import com.bank.model.Employee;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeRepository extends MongoRepository<Employee, String> {

    List<Employee> findByBranchId(String branchId);

    Optional<Employee> findByEmployeeId(String employeeId);

    boolean existsByEmployeeId(String employeeId);

    boolean existsByEmail(String email);

    List<Employee> findByBranchIdAndDesignation(String branchId, String designation);

    List<Employee> findByDepartment(String department);

    List<Employee> findByBranchIdAndStatus(String branchId, String status);

    long countByBranchId(String branchId);

    boolean existsByBranchId(String branchId);
}
