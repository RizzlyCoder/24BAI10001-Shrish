package com.bank.controller;

import com.bank.dto.response.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;


@RestController
@RequiredArgsConstructor
@RequestMapping("/api/health")
@Tag(name = "Health Check", description = "System and database health endpoints")
public class HealthController {

    private final MongoTemplate mongoTemplate;

    
    // GET /api/health
    

    @GetMapping
    @Operation(
        summary = "Application health check",
        description = "Returns the current status of the application and timestamp."
    )
    public ResponseEntity<ApiResponse<Map<String, Object>>> health() {

        Map<String, Object> status = new LinkedHashMap<>();
        status.put("application",  "Banking Management System");
        status.put("status",       "UP");
        status.put("version",      "1.0.0");
        status.put("timestamp",    LocalDateTime.now().toString());
        status.put("swagger_ui",   "http://localhost:8080/swagger-ui/index.html");

        return ResponseEntity.ok(
                ApiResponse.success("Application is running", status));
    }

    
    // GET /api/health/db
    

    @GetMapping("/db")
    @Operation(
        summary = "Database health check",
        description = "Verifies MongoDB connectivity and lists all existing collections."
    )
    public ResponseEntity<ApiResponse<Map<String, Object>>> dbHealth() {

        Map<String, Object> dbStatus = new LinkedHashMap<>();

        try {
            // Attempt to list collections — throws if MongoDB is unreachable
            Set<String> collections = mongoTemplate.getCollectionNames();

            dbStatus.put("mongodb",     "CONNECTED");
            dbStatus.put("database",    mongoTemplate.getDb().getName());
            dbStatus.put("collections", collections);
            dbStatus.put("count",       collections.size());

            return ResponseEntity.ok(
                    ApiResponse.success("MongoDB connection is healthy", dbStatus));

        } catch (Exception e) {
            dbStatus.put("mongodb", "DISCONNECTED");
            dbStatus.put("error",   e.getMessage());

            return ResponseEntity.status(503)
                    .body(ApiResponse.error("MongoDB connection failed: " + e.getMessage()));
        }
    }
}
