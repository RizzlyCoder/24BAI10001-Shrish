package com.bank.util;

import java.util.concurrent.atomic.AtomicLong;

public final class AccountNumberGenerator {

    private AccountNumberGenerator() {}

    private static final AtomicLong counter = new AtomicLong(
            System.currentTimeMillis() % 1_000_000_000L
    );

    public static String generate(String accountType) {
        long number = counter.incrementAndGet();

        String prefix = switch (accountType.toUpperCase()) {
            case "SAVINGS" -> "SB";
            case "CURRENT" -> "CB";
            case "FIXED"   -> "FB";
            default        -> "AB";
        };

        return prefix + String.format("%010d", number);
    }
}
