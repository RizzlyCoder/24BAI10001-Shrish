package com.bank.controller;

import com.bank.dto.request.CustomerRequest;
import com.bank.dto.response.ApiResponse;
import com.bank.dto.response.CustomerResponse;
import com.bank.service.CustomerService;
import com.bank.util.AppConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
HTTP STATUS CODES USED:
   201 CREATED       → successful POST (new resource created)
   200 OK            → successful GET, PUT
   204 NO CONTENT    → successful DELETE (no body to return)
   400 BAD REQUEST   → validation failure (handled by GlobalExceptionHandler)
   404 NOT FOUND     → resource missing (handled by GlobalExceptionHandler)
   409 CONFLICT      → duplicate resource (handled by GlobalExceptionHandler)
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/customers")
@Tag(name = "Customer Management", description = "APIs for managing bank customers")
public class CustomerController {

    private final CustomerService customerService;

    
    // POST /api/customers — Create Customer
    

    
    @PostMapping
    @Operation(summary = "Create a new customer",
               description = "Registers a new customer in the banking system. Email must be unique.")
    public ResponseEntity<ApiResponse<CustomerResponse>> createCustomer(
            @Valid @RequestBody CustomerRequest request) {

        log.info("POST /api/customers — creating customer: {}", request.getEmail());

        CustomerResponse response = customerService.createCustomer(request);

        return ResponseEntity
                .status(HttpStatus.CREATED)           // 201
                .body(ApiResponse.success(AppConstants.CUSTOMER_CREATED, response));
    }

    
    // GET /api/customers — Get All Customers
    

    @GetMapping
    @Operation(summary = "Get all customers",
               description = "Returns a list of all registered customers.")
    public ResponseEntity<ApiResponse<List<CustomerResponse>>> getAllCustomers() {

        log.info("GET /api/customers — fetching all customers");

        List<CustomerResponse> customers = customerService.getAllCustomers();

        return ResponseEntity.ok(
                ApiResponse.success("Fetched " + customers.size() + " customer(s)", customers));
    }

    
    // GET /api/customers/{id} — Get Customer By ID
    

    
    @GetMapping("/{id}")
    @Operation(summary = "Get customer by ID",
               description = "Fetches a single customer using their MongoDB ID.")
    public ResponseEntity<ApiResponse<CustomerResponse>> getCustomerById(
            @Parameter(description = "MongoDB ID of the customer", example = "664f1a2b3c4d5e6f7a8b9c0d")
            @PathVariable String id) {

        log.info("GET /api/customers/{} — fetching customer", id);

        CustomerResponse response = customerService.getCustomerById(id);

        return ResponseEntity.ok(
                ApiResponse.success("Customer fetched successfully", response));
    }

    
    // PUT /api/customers/{id} — Update Customer
    

    
    @PutMapping("/{id}")
    @Operation(summary = "Update an existing customer",
               description = "Updates all fields of an existing customer. All fields are required.")
    public ResponseEntity<ApiResponse<CustomerResponse>> updateCustomer(
            @Parameter(description = "MongoDB ID of the customer to update")
            @PathVariable String id,
            @Valid @RequestBody CustomerRequest request) {

        log.info("PUT /api/customers/{} — updating customer", id);

        CustomerResponse response = customerService.updateCustomer(id, request);

        return ResponseEntity.ok(
                ApiResponse.success(AppConstants.CUSTOMER_UPDATED, response));
    }

    
    // DELETE /api/customers/{id} — Delete Customer
    

    
    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a customer",
               description = "Permanently removes a customer from the system.")
    public ResponseEntity<ApiResponse<Void>> deleteCustomer(
            @Parameter(description = "MongoDB ID of the customer to delete")
            @PathVariable String id) {

        log.info("DELETE /api/customers/{} — deleting customer", id);

        customerService.deleteCustomer(id);

        return ResponseEntity
                .status(HttpStatus.OK)
                .body(ApiResponse.success(AppConstants.CUSTOMER_DELETED));
    }
}
