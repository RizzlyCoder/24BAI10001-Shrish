package com.bank.service.impl;

import com.bank.dto.request.AddCustomerRequest;
import com.bank.dto.request.JointAccountRequest;
import com.bank.dto.response.JointAccountResponse;
import com.bank.exception.InvalidOperationException;
import com.bank.exception.ResourceNotFoundException;
import com.bank.model.Customer;
import com.bank.model.JointAccount;
import com.bank.repository.CustomerRepository;
import com.bank.repository.JointAccountRepository;
import com.bank.service.JointAccountService;
import com.bank.util.AppConstants;
import com.bank.util.AccountNumberGenerator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * JointAccountServiceImpl — implements full Many-to-Many management.
 *
 * THIS CLASS DEMONSTRATES:
 *
 * 1. CREATE with array initialisation:
 *    Validate all customerIds → build customerIds list → save with array
 *
 * 2. ADD to array ($addToSet equivalent):
 *    Fetch document → check not already present → list.add() → save
 *    MongoDB's $addToSet prevents duplicates in arrays.
 *    We replicate this behaviour at the application level.
 *
 * 3. REMOVE from array ($pull equivalent):
 *    Fetch document → check present → check min 2 rule → list.remove() → save
 *    MongoDB's $pull removes matching elements from arrays.
 *    We replicate this behaviour at the application level.
 *
 * 4. ENRICHED RESPONSE building:
 *    After fetching a JointAccount, we look up each customer in the
 *    customerIds list and build a CustomerSummary for the response.
 *    This turns raw IDs into human-readable names + emails.
 *
 * DEPENDENCIES:
 *   JointAccountRepository → CRUD for joint_accounts collection
 *   CustomerRepository     → to validate customerIds and build enriched responses
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class JointAccountServiceImpl implements JointAccountService {

    private final JointAccountRepository jointAccountRepository;
    private final CustomerRepository     customerRepository;

    // ===================================================================
    // CREATE
    // ===================================================================

    /**
     * Joint account creation flow:
     *   1. Validate all provided customerIds exist in the customers collection
     *   2. Enforce minimum 2 customers rule
     *   3. Generate unique account number (JT prefix)
     *   4. Build JointAccount with customerIds array
     *   5. Save and return enriched response
     */
    @Override
    public JointAccountResponse createJointAccount(JointAccountRequest request) {
        log.info("Creating joint account with {} customers", request.getCustomerIds().size());

        // ── Step 1: Validate every customerId refers to a real customer ───
        List<Customer> validatedCustomers = validateAndFetchCustomers(
                request.getCustomerIds(), "create joint account");

        // ── Step 2: @Size(min=2) in DTO already checked, but we double-check
        //           here because the service is the authoritative business layer
        if (validatedCustomers.size() < 2) {
            throw new InvalidOperationException(AppConstants.MIN_CUSTOMERS_REQUIRED);
        }

        // ── Step 3: Generate unique account number with "JT" prefix ──────
        String accountNumber;
        do {
            accountNumber = "JT" + String.format("%010d",
                    System.currentTimeMillis() % 1_000_000_000L);
        } while (jointAccountRepository.existsByAccountNumber(accountNumber));

        // ── Step 4: Build the JointAccount entity ────────────────────────
        // Store only the IDs in the document (not full customer objects)
        List<String> customerIds = new ArrayList<>(request.getCustomerIds());

        JointAccount jointAccount = JointAccount.builder()
                .accountNumber(accountNumber)
                .customerIds(customerIds)
                .balance(BigDecimal.ZERO)
                .description(request.getDescription())
                .status("ACTIVE")
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        JointAccount saved = jointAccountRepository.save(jointAccount);
        log.info("Joint account created: {} with {} holders",
                saved.getAccountNumber(), saved.getCustomerIds().size());

        // ── Step 5: Return enriched response (IDs → CustomerSummary objects)
        return buildEnrichedResponse(saved, validatedCustomers);
    }

    // ===================================================================
    // READ ALL
    // ===================================================================

    @Override
    public List<JointAccountResponse> getAllJointAccounts() {
        log.info("Fetching all joint accounts");

        return jointAccountRepository.findAll()
                .stream()
                .map(ja -> buildEnrichedResponse(ja, fetchCustomersForJointAccount(ja)))
                .collect(Collectors.toList());
    }

    // ===================================================================
    // READ BY ID
    // ===================================================================

    @Override
    public JointAccountResponse getJointAccountById(String id) {
        log.info("Fetching joint account by ID: {}", id);

        JointAccount jointAccount = findJointAccountById(id);
        List<Customer> customers = fetchCustomersForJointAccount(jointAccount);

        return buildEnrichedResponse(jointAccount, customers);
    }

    // ===================================================================
    // READ BY CUSTOMER ID — MANY-TO-MANY REVERSE LOOKUP
    // ===================================================================

    /**
     * "Which joint accounts does customer X belong to?"
     *
     * MONGODB QUERY BEHIND THIS:
     *   db.joint_accounts.find({ customer_ids: customerId })
     *
     *   MongoDB automatically checks if customerId appears anywhere
     *   in the customer_ids array — no extra syntax needed.
     *   Spring Data keyword "Containing" maps to this behaviour.
     *
     * This is the reverse traversal of the Many-to-Many:
     *   Forward:  jointAccount.customerIds → list of customers
     *   Reverse:  customer → all jointAccounts containing that customer
     */
    @Override
    public List<JointAccountResponse> getJointAccountsByCustomerId(String customerId) {
        log.info("Fetching all joint accounts for customer: {}", customerId);

        // Validate the customer exists first
        if (!customerRepository.existsById(customerId)) {
            throw new ResourceNotFoundException(
                    AppConstants.CUSTOMER_NOT_FOUND + customerId);
        }

        // This query searches inside the array field — MongoDB native behaviour
        List<JointAccount> jointAccounts =
                jointAccountRepository.findByCustomerIdsContaining(customerId);

        log.info("Found {} joint account(s) for customer: {}", jointAccounts.size(), customerId);

        return jointAccounts.stream()
                .map(ja -> buildEnrichedResponse(ja, fetchCustomersForJointAccount(ja)))
                .collect(Collectors.toList());
    }

    // ===================================================================
    // ADD CUSTOMER — MANY-TO-MANY: ADD TO ARRAY
    // ===================================================================

    /**
     * Add a customer to an existing joint account.
     *
     * ARRAY OPERATION — equivalent to MongoDB's $addToSet:
     *   db.joint_accounts.updateOne(
     *     { _id: jointAccountId },
     *     { $addToSet: { customer_ids: customerId } }
     *   )
     *
     * We replicate $addToSet behaviour manually:
     *   1. Fetch the document (loads the current array)
     *   2. Check if customerId is already in the array
     *   3. Add it if not present
     *   4. Save the updated document
     *
     * WHY NOT USE MongoTemplate directly for $addToSet?
     *   For an academic project, fetching and saving is clearer and easier
     *   to understand. MongoTemplate with $addToSet is more efficient
     *   (one DB call) but adds complexity. Both approaches are correct.
     */
    @Override
    public JointAccountResponse addCustomerToJointAccount(
            String jointAccountId, AddCustomerRequest request) {

        log.info("Adding customer {} to joint account {}", request.getCustomerId(), jointAccountId);

        // Step 1: Find the joint account
        JointAccount jointAccount = findJointAccountById(jointAccountId);

        // Step 2: Validate the customer to be added actually exists
        Customer customerToAdd = customerRepository
                .findById(request.getCustomerId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        AppConstants.CUSTOMER_NOT_FOUND + request.getCustomerId()));

        // Step 3: Check the customer isn't already in this joint account
        if (jointAccount.getCustomerIds().contains(request.getCustomerId())) {
            throw new InvalidOperationException(
                    AppConstants.CUSTOMER_ALREADY_IN_JOINT);
        }

        // Step 4: Add to the array (equivalent to $addToSet)
        jointAccount.getCustomerIds().add(request.getCustomerId());
        jointAccount.setUpdatedAt(LocalDateTime.now());

        JointAccount updated = jointAccountRepository.save(jointAccount);
        log.info("Customer {} added. Joint account {} now has {} holders",
                customerToAdd.getFullName(),
                updated.getAccountNumber(),
                updated.getCustomerIds().size());

        return buildEnrichedResponse(updated, fetchCustomersForJointAccount(updated));
    }

    // ===================================================================
    // REMOVE CUSTOMER — MANY-TO-MANY: REMOVE FROM ARRAY
    // ===================================================================

    /**
     * Remove a customer from an existing joint account.
     *
     * ARRAY OPERATION — equivalent to MongoDB's $pull:
     *   db.joint_accounts.updateOne(
     *     { _id: jointAccountId },
     *     { $pull: { customer_ids: customerId } }
     *   )
     *
     * CRITICAL BUSINESS RULE:
     *   After removal, the array must still have at least 2 customers.
     *   A joint account with 1 customer is semantically invalid —
     *   it becomes a regular account at that point.
     *   We throw InvalidOperationException before removing if this would
     *   leave fewer than 2 holders.
     *
     * FLOW:
     *   1. Find the joint account
     *   2. Check the customer IS currently in the account
     *   3. Check removal won't breach the minimum-2 rule
     *   4. Remove from the array
     *   5. Save and return updated response
     */
    @Override
    public JointAccountResponse removeCustomerFromJointAccount(
            String jointAccountId, AddCustomerRequest request) {

        log.info("Removing customer {} from joint account {}",
                request.getCustomerId(), jointAccountId);

        // Step 1: Find the joint account
        JointAccount jointAccount = findJointAccountById(jointAccountId);

        // Step 2: Check the customer is actually IN this joint account
        if (!jointAccount.getCustomerIds().contains(request.getCustomerId())) {
            throw new InvalidOperationException(AppConstants.CUSTOMER_NOT_IN_JOINT);
        }

        // Step 3: Minimum 2 customers rule — BEFORE removing
        if (jointAccount.getCustomerIds().size() <= 2) {
            throw new InvalidOperationException(
                    "Cannot remove customer: joint account must have at least 2 customers. " +
                    "Current count: " + jointAccount.getCustomerIds().size() +
                    ". Delete the joint account instead if you wish to close it.");
        }

        // Step 4: Remove from the array (equivalent to $pull)
        jointAccount.getCustomerIds().remove(request.getCustomerId());
        jointAccount.setUpdatedAt(LocalDateTime.now());

        JointAccount updated = jointAccountRepository.save(jointAccount);
        log.info("Customer removed. Joint account {} now has {} holders",
                updated.getAccountNumber(), updated.getCustomerIds().size());

        return buildEnrichedResponse(updated, fetchCustomersForJointAccount(updated));
    }

    // ===================================================================
    // DELETE
    // ===================================================================

    /**
     * Delete a joint account.
     * Business rule: balance must be zero before deletion.
     */
    @Override
    public void deleteJointAccount(String id) {
        log.info("Deleting joint account with ID: {}", id);

        JointAccount jointAccount = findJointAccountById(id);

        if (jointAccount.getBalance().compareTo(BigDecimal.ZERO) > 0) {
            throw new InvalidOperationException(
                    "Cannot delete joint account " + jointAccount.getAccountNumber() +
                    ": account still has a balance of ₹" + jointAccount.getBalance() +
                    ". Please withdraw all funds before closing.");
        }

        jointAccountRepository.deleteById(id);
        log.info("Joint account deleted: {}", jointAccount.getAccountNumber());
    }

    // ===================================================================
    // PRIVATE HELPERS
    // ===================================================================

    /**
     * Finds a JointAccount by ID or throws ResourceNotFoundException.
     * Extracted to avoid repeating this pattern in every method.
     */
    private JointAccount findJointAccountById(String id) {
        return jointAccountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        AppConstants.JOINT_ACCOUNT_NOT_FOUND + id));
    }

    /**
     * Validates a list of customerIds and fetches the Customer documents.
     *
     * WHY THIS HELPER?
     *   Used in createJointAccount() to:
     *   (a) Confirm every provided ID actually exists in the DB
     *   (b) Return the Customer objects for response enrichment
     *
     * If ANY customerId in the list is invalid, we throw immediately
     * with a clear message identifying which ID was not found.
     *
     * @param customerIds list of MongoDB _ids to validate
     * @param operation   human-readable operation name for error messages
     * @return list of validated Customer entities
     */
    private List<Customer> validateAndFetchCustomers(
            List<String> customerIds, String operation) {

        List<Customer> customers = new ArrayList<>();

        for (String customerId : customerIds) {
            Customer customer = customerRepository.findById(customerId)
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Cannot " + operation + ": " +
                            AppConstants.CUSTOMER_NOT_FOUND + customerId));
            customers.add(customer);
        }

        return customers;
    }

    /**
     * Fetches all Customer documents for a given JointAccount's customerIds.
     * Used when building enriched responses after fetch operations.
     *
     * Note: Customers who no longer exist (deleted after account creation)
     * are silently skipped. In production you'd handle this more carefully.
     */
    private List<Customer> fetchCustomersForJointAccount(JointAccount jointAccount) {
        return jointAccount.getCustomerIds()
                .stream()
                .map(customerId -> customerRepository.findById(customerId).orElse(null))
                .filter(customer -> customer != null)
                .collect(Collectors.toList());
    }

    /**
     * Builds an enriched JointAccountResponse by combining:
     *   - JointAccount entity data (account number, balance, status, etc.)
     *   - Customer data (fullName, email for each holder)
     *
     * The enrichment converts raw customerIds (array of strings) into
     * meaningful CustomerSummary objects for the API consumer.
     *
     * @param jointAccount the saved JointAccount document
     * @param customers    the fetched Customer documents for all holders
     * @return fully populated JointAccountResponse
     */
    private JointAccountResponse buildEnrichedResponse(
            JointAccount jointAccount, List<Customer> customers) {

        // Convert each Customer entity to a lightweight CustomerSummary
        List<JointAccountResponse.CustomerSummary> summaries = customers.stream()
                .map(customer -> JointAccountResponse.CustomerSummary.builder()
                        .id(customer.getId())
                        .fullName(customer.getFullName())
                        .email(customer.getEmail())
                        .build())
                .collect(Collectors.toList());

        return JointAccountResponse.builder()
                .id(jointAccount.getId())
                .accountNumber(jointAccount.getAccountNumber())
                .customers(summaries)
                .balance(jointAccount.getBalance())
                .description(jointAccount.getDescription())
                .status(jointAccount.getStatus())
                .createdAt(jointAccount.getCreatedAt())
                .updatedAt(jointAccount.getUpdatedAt())
                .build();
    }
}
