package com.bank.service.impl;

import com.bank.dto.request.AccountRequest;
import com.bank.dto.response.AccountResponse;
import com.bank.exception.InvalidOperationException;
import com.bank.exception.ResourceNotFoundException;
import com.bank.model.Account;
import com.bank.repository.AccountRepository;
import com.bank.repository.CustomerRepository;
import com.bank.service.AccountService;
import com.bank.util.AccountNumberGenerator;
import com.bank.util.AppConstants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * AccountServiceImpl — implements all account business logic.
 *
 * RELATIONSHIP ENFORCEMENT:
 *   This class is where the Customer → Account relationship is enforced.
 *   We inject BOTH CustomerRepository and AccountRepository because
 *   we need to:
 *     1. Verify the customer EXISTS before creating an account for them
 *     2. Fetch accounts by customerId to traverse the relationship
 *
 *   MongoDB doesn't enforce this for us — we do it in the service layer.
 *   This is the standard pattern in MongoDB-based Spring Boot applications.
 *
 * MINIMUM BALANCE RULES (enforced here, not in the model):
 *   SAVINGS  → ₹1,000
 *   CURRENT  → ₹5,000
 *   FIXED    → ₹10,000
 *
 * These are business rules, so they belong in the service layer —
 * not the model (which just holds data) and not the controller (which
 * handles HTTP concerns only).
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AccountServiceImpl implements AccountService {

    private final AccountRepository  accountRepository;
    private final CustomerRepository customerRepository;  // needed for relationship validation

    // ===================================================================
    // MINIMUM BALANCE CONSTANTS
    // ===================================================================
    private static final BigDecimal MIN_BALANCE_SAVINGS = new BigDecimal("1000.00");
    private static final BigDecimal MIN_BALANCE_CURRENT = new BigDecimal("5000.00");
    private static final BigDecimal MIN_BALANCE_FIXED   = new BigDecimal("10000.00");

    // ===================================================================
    // CREATE
    // ===================================================================

    @Override
    public AccountResponse createAccount(AccountRequest request) {
        log.info("Creating {} account for customer: {}", request.getAccountType(), request.getCustomerId());

        // ── STEP 1: Relationship validation ──────────────────────────────
        // Business Rule: "Account creation requires an existing customer."
        // We manually check that the customerId refers to a real Customer document.
        if (!customerRepository.existsById(request.getCustomerId())) {
            throw new ResourceNotFoundException(
                    AppConstants.CUSTOMER_NOT_FOUND + request.getCustomerId());
        }

        // ── STEP 2: Determine minimum balance based on account type ──────
        BigDecimal minimumBalance = resolveMinimumBalance(request.getAccountType());

        // ── STEP 3: Generate a unique account number ─────────────────────
        // Loop until we find one that doesn't already exist in the DB.
        // In practice, the AtomicLong makes collision near-impossible.
        String accountNumber;
        do {
            accountNumber = AccountNumberGenerator.generate(request.getAccountType());
        } while (accountRepository.existsByAccountNumber(accountNumber));

        // ── STEP 4: Build and save the Account entity ────────────────────
        Account account = Account.builder()
                .accountNumber(accountNumber)
                .accountType(request.getAccountType().toUpperCase())
                .balance(BigDecimal.ZERO)        // starts at zero
                .minimumBalance(minimumBalance)
                .customerId(request.getCustomerId())
                .status("ACTIVE")
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        Account savedAccount = accountRepository.save(account);
        log.info("Account created: {} for customer: {}", savedAccount.getAccountNumber(), request.getCustomerId());

        return AccountResponse.fromEntity(savedAccount);
    }

    // ===================================================================
    // READ ALL
    // ===================================================================

    @Override
    public List<AccountResponse> getAllAccounts() {
        log.info("Fetching all accounts");

        return accountRepository.findAll()
                .stream()
                .map(AccountResponse::fromEntity)
                .collect(Collectors.toList());
    }

    // ===================================================================
    // READ BY ID
    // ===================================================================

    @Override
    public AccountResponse getAccountById(String id) {
        log.info("Fetching account by ID: {}", id);

        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        AppConstants.ACCOUNT_NOT_FOUND + id));

        return AccountResponse.fromEntity(account);
    }

    // ===================================================================
    // READ BY CUSTOMER ID  ← ONE-TO-MANY TRAVERSAL
    // ===================================================================

    /**
     * This method implements the One-to-Many relationship traversal:
     *   "Get all accounts for Customer X"
     *
     * Flow:
     *   1. Verify the customer exists (throw 404 if not)
     *   2. Query accounts collection: find({ customer_id: customerId })
     *   3. Map results to response DTOs
     *
     * This is how you "join" in MongoDB — not with a SQL JOIN, but by:
     *   a) Storing the reference (customerId field in Account)
     *   b) Querying by that reference when needed
     */
    @Override
    public List<AccountResponse> getAccountsByCustomerId(String customerId) {
        log.info("Fetching all accounts for customer: {}", customerId);

        // Step 1: Verify customer exists
        if (!customerRepository.existsById(customerId)) {
            throw new ResourceNotFoundException(
                    AppConstants.CUSTOMER_NOT_FOUND + customerId);
        }

        // Step 2: Query accounts by customerId
        return accountRepository.findByCustomerId(customerId)
                .stream()
                .map(AccountResponse::fromEntity)
                .collect(Collectors.toList());
    }

    // ===================================================================
    // UPDATE
    // ===================================================================

    /**
     * Update rules:
     *   - customerId CANNOT be changed (accounts don't transfer between customers)
     *   - accountNumber CANNOT be changed (immutable once issued)
     *   - balance is NOT updated here (only through Transaction APIs)
     *   - accountType CAN be updated (e.g., upgrade SAVINGS → CURRENT)
     *     though in practice this is rare; we support it here for completeness
     */
    @Override
    public AccountResponse updateAccount(String id, AccountRequest request) {
        log.info("Updating account with ID: {}", id);

        // Step 1: Find existing account
        Account existingAccount = accountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        AppConstants.ACCOUNT_NOT_FOUND + id));

        // Step 2: Verify that the new customerId (if changed) still exists
        if (!customerRepository.existsById(request.getCustomerId())) {
            throw new ResourceNotFoundException(
                    AppConstants.CUSTOMER_NOT_FOUND + request.getCustomerId());
        }

        // Step 3: Changing account type? Recalculate minimum balance
        if (!existingAccount.getAccountType().equals(request.getAccountType().toUpperCase())) {
            log.info("Account type changing from {} to {}",
                    existingAccount.getAccountType(), request.getAccountType());

            // Check: if new minimum balance > current balance, block the change
            BigDecimal newMinBalance = resolveMinimumBalance(request.getAccountType());
            if (existingAccount.getBalance().compareTo(newMinBalance) < 0) {
                throw new InvalidOperationException(
                        "Cannot change account type: current balance (" +
                        existingAccount.getBalance() +
                        ") is below the minimum balance required for " +
                        request.getAccountType() + " accounts (" + newMinBalance + ")");
            }

            existingAccount.setAccountType(request.getAccountType().toUpperCase());
            existingAccount.setMinimumBalance(newMinBalance);
        }

        existingAccount.setCustomerId(request.getCustomerId());
        existingAccount.setUpdatedAt(LocalDateTime.now());

        Account updatedAccount = accountRepository.save(existingAccount);
        log.info("Account updated: {}", updatedAccount.getAccountNumber());

        return AccountResponse.fromEntity(updatedAccount);
    }

    // ===================================================================
    // DELETE
    // ===================================================================

    /**
     * Delete rules:
     *   - Account must exist
     *   - Balance must be zero before deletion (can't delete an account with funds)
     *   - In production, this would be a "CLOSE" status change, not hard delete
     */
    @Override
    public void deleteAccount(String id) {
        log.info("Deleting account with ID: {}", id);

        Account account = accountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        AppConstants.ACCOUNT_NOT_FOUND + id));

        // Business rule: Cannot delete an account that still has a balance
        if (account.getBalance().compareTo(BigDecimal.ZERO) > 0) {
            throw new InvalidOperationException(
                    "Cannot delete account " + account.getAccountNumber() +
                    ": account still has a balance of ₹" + account.getBalance() +
                    ". Please withdraw all funds before closing the account.");
        }

        accountRepository.deleteById(id);
        log.info("Account deleted: {}", account.getAccountNumber());
    }

    // ===================================================================
    // PRIVATE HELPER
    // ===================================================================

    /**
     * Determines the minimum balance for a given account type.
     * This is a business rule — lives in the service layer.
     *
     * @param accountType "SAVINGS", "CURRENT", or "FIXED"
     * @return minimum balance as BigDecimal
     */
    private BigDecimal resolveMinimumBalance(String accountType) {
        return switch (accountType.toUpperCase()) {
            case "SAVINGS" -> MIN_BALANCE_SAVINGS;
            case "CURRENT" -> MIN_BALANCE_CURRENT;
            case "FIXED"   -> MIN_BALANCE_FIXED;
            default -> BigDecimal.ZERO;
        };
    }
}
