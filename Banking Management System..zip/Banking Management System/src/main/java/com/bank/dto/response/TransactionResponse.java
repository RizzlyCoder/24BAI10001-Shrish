package com.bank.dto.response;

import com.bank.model.Transaction;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Transaction details returned in API responses")
public class TransactionResponse {

    @Schema(description = "Unique transaction ID")
    private String id;

    @Schema(description = "Type: DEPOSIT, WITHDRAWAL, TRANSFER_DEBIT, TRANSFER_CREDIT",
            example = "DEPOSIT")
    private String transactionType;

    @Schema(description = "Transaction amount", example = "5000.00")
    private BigDecimal amount;

    @Schema(description = "Account this transaction belongs to")
    private String accountId;

    @Schema(description = "Account balance after this transaction was applied",
            example = "5000.00")
    private BigDecimal balanceAfter;

    @Schema(description = "For transfers: the other account involved")
    private String relatedAccountId;

    @Schema(description = "Optional description / note", example = "Salary deposit")
    private String description;

    @Schema(description = "When this transaction occurred")
    private LocalDateTime createdAt;

    public static TransactionResponse fromEntity(Transaction transaction) {
        return TransactionResponse.builder()
                .id(transaction.getId())
                .transactionType(transaction.getTransactionType())
                .amount(transaction.getAmount())
                .accountId(transaction.getAccountId())
                .balanceAfter(transaction.getBalanceAfter())
                .relatedAccountId(transaction.getRelatedAccountId())
                .description(transaction.getDescription())
                .createdAt(transaction.getCreatedAt())
                .build();
    }
}
