package com.bank.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.*;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request payload for creating a new bank account")
public class AccountRequest {

    
    @NotBlank(message = "Customer ID is required")
    @Schema(description = "MongoDB ID of the existing customer",
            example = "664f1a2b3c4d5e6f7a8b9c0d")
    private String customerId;

    
    @NotBlank(message = "Account type is required")
    @Pattern(
        regexp = "^(SAVINGS|CURRENT|FIXED)$",
        message = "Account type must be SAVINGS, CURRENT, or FIXED"
    )
    @Schema(description = "Type of account to create",
            example = "SAVINGS",
            allowableValues = {"SAVINGS", "CURRENT", "FIXED"})
    private String accountType;
}
