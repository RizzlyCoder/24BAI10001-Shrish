package com.bank.dto.response;

import com.bank.model.JointAccount;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Joint account data returned in API responses")
public class JointAccountResponse {

    @Schema(description = "MongoDB-generated unique ID")
    private String id;

    @Schema(description = "System-generated joint account number", example = "JT0000000001")
    private String accountNumber;

    
    @Schema(description = "List of customers who co-own this joint account")
    private List<CustomerSummary> customers;

    @Schema(description = "Current shared balance", example = "10000.00")
    private BigDecimal balance;

    @Schema(description = "Optional description of the account purpose",
            example = "Family savings account")
    private String description;

    @Schema(description = "Account status: ACTIVE, INACTIVE, CLOSED", example = "ACTIVE")
    private String status;

    @Schema(description = "When the joint account was created")
    private LocalDateTime createdAt;

    @Schema(description = "When the joint account was last updated")
    private LocalDateTime updatedAt;

    
    // STATIC INNER CLASS — CustomerSummary
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Lightweight customer information for joint account display")
    public static class CustomerSummary {

        @Schema(description = "MongoDB ID of the customer")
        private String id;

        @Schema(description = "Customer's full name", example = "Rahul Sharma")
        private String fullName;

        @Schema(description = "Customer's email address", example = "rahul@example.com")
        private String email;
    }

   
    public static JointAccountResponse fromEntity(JointAccount jointAccount) {
        return JointAccountResponse.builder()
                .id(jointAccount.getId())
                .accountNumber(jointAccount.getAccountNumber())
                .balance(jointAccount.getBalance())
                .description(jointAccount.getDescription())
                .status(jointAccount.getStatus())
                .createdAt(jointAccount.getCreatedAt())
                .updatedAt(jointAccount.getUpdatedAt())
                .build();
    }
}
