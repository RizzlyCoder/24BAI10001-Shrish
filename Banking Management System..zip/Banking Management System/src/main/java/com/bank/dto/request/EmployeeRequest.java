package com.bank.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request payload for creating or updating an employee")
public class EmployeeRequest {

    @NotBlank(message = "Full name is required")
    @Size(min = 2, max = 100, message = "Full name must be between 2 and 100 characters")
    @Schema(description = "Employee's full name", example = "Priya Nair")
    private String fullName;

    @NotBlank(message = "Email is required")
    @Email(message = "Email must be a valid email address")
    @Schema(description = "Employee's unique work email", example = "priya.nair@bank.com")
    private String email;

    @NotBlank(message = "Phone number is required")
    @Pattern(
        regexp = "^[6-9]\\d{9}$",
        message = "Phone must be a valid 10-digit Indian mobile number starting with 6-9"
    )
    @Schema(description = "10-digit mobile number", example = "9876543210")
    private String phone;

    @NotBlank(message = "Designation is required")
    @Size(min = 2, max = 100, message = "Designation must be between 2 and 100 characters")
    @Schema(description = "Job title / role", example = "Branch Manager")
    private String designation;

    @NotBlank(message = "Department is required")
    @Size(min = 2, max = 100, message = "Department must be between 2 and 100 characters")
    @Schema(description = "Department within the bank", example = "Management")
    private String department;

    @NotNull(message = "Salary is required")
    @DecimalMin(value = "1.00", message = "Salary must be at least ₹1")
    @Digits(
        integer = 10,
        fraction = 2,
        message = "Salary must have at most 10 digits before and 2 digits after decimal"
    )
    @Schema(description = "Monthly salary in INR", example = "75000.00")
    private BigDecimal salary;

    @NotNull(message = "Date of joining is required")
    @PastOrPresent(message = "Date of joining cannot be in the future")
    @Schema(description = "Date of joining in yyyy-MM-dd format", example = "2022-03-15")
    private LocalDate dateOfJoining;

    
    @NotBlank(message = "Branch ID is required")
    @Schema(description = "MongoDB ID of the branch this employee belongs to",
            example = "664f1a2b3c4d5e6f7a8b9c0d")
    private String branchId;
}
