package com.bank.util;


public final class AppConstants {

    private AppConstants() {
        throw new UnsupportedOperationException("Utility class — do not instantiate");
    }

    

    // Customer
    public static final String CUSTOMER_CREATED      = "Customer created successfully";
    public static final String CUSTOMER_UPDATED      = "Customer updated successfully";
    public static final String CUSTOMER_DELETED      = "Customer deleted successfully";

    // Account
    public static final String ACCOUNT_CREATED       = "Account created successfully";
    public static final String ACCOUNT_UPDATED       = "Account updated successfully";
    public static final String ACCOUNT_DELETED       = "Account deleted successfully";

    // Transaction
    public static final String DEPOSIT_SUCCESS       = "Amount deposited successfully";
    public static final String WITHDRAW_SUCCESS      = "Amount withdrawn successfully";
    public static final String TRANSFER_SUCCESS      = "Amount transferred successfully";

    // Branch
    public static final String BRANCH_CREATED        = "Branch created successfully";
    public static final String BRANCH_UPDATED        = "Branch updated successfully";
    public static final String BRANCH_DELETED        = "Branch deleted successfully";

    // Employee
    public static final String EMPLOYEE_CREATED      = "Employee created successfully";
    public static final String EMPLOYEE_UPDATED      = "Employee updated successfully";
    public static final String EMPLOYEE_DELETED      = "Employee deleted successfully";

    // Joint Account
    public static final String JOINT_ACCOUNT_CREATED = "Joint account created successfully";
    public static final String JOINT_ACCOUNT_DELETED = "Joint account deleted successfully";
    public static final String CUSTOMER_ADDED        = "Customer added to joint account successfully";
    public static final String CUSTOMER_REMOVED      = "Customer removed from joint account successfully";

    
    // NOT FOUND ERRORS (append the offending ID at the call site)
    

    public static final String CUSTOMER_NOT_FOUND      = "Customer not found with ID: ";
    public static final String ACCOUNT_NOT_FOUND       = "Account not found with ID: ";
    public static final String BRANCH_NOT_FOUND        = "Branch not found with ID: ";
    public static final String EMPLOYEE_NOT_FOUND      = "Employee not found with ID: ";
    public static final String JOINT_ACCOUNT_NOT_FOUND = "Joint account not found with ID: ";
    public static final String TRANSACTION_NOT_FOUND   = "Transaction not found with ID: ";

    
    // BUSINESS RULE ERRORS
    

    public static final String INSUFFICIENT_BALANCE        = "Insufficient balance in account: ";
    public static final String SAME_ACCOUNT_TRANSFER       = "Source and destination accounts cannot be the same";
    public static final String INVALID_AMOUNT              = "Amount must be greater than zero";
    public static final String MIN_CUSTOMERS_REQUIRED      = "A joint account must have at least 2 customers";
    public static final String CUSTOMER_ALREADY_IN_JOINT   = "Customer is already a member of this joint account";
    public static final String CUSTOMER_NOT_IN_JOINT       = "Customer is not a member of this joint account";

    
    // DUPLICATE ERRORS
    

    public static final String DUPLICATE_EMAIL          = "A customer with this email already exists: ";
    public static final String DUPLICATE_ACCOUNT_NUMBER = "Account number already exists: ";
}
