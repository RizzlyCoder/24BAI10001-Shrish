package com.bank.service;

import com.bank.dto.request.AccountRequest;
import com.bank.dto.response.AccountResponse;

import java.util.List;

/**
 * AccountService — contract for all account business operations.
 *
 * Notice the relationship queries defined here:
 *   getAccountsByCustomerId() → implements "get all accounts for a customer"
 *   This is how you traverse the One-to-Many relationship from the API level.
 */
public interface AccountService {

    /**
     * Create a new account for an existing customer.
     * Business rules enforced in impl:
     *   - customerId must refer to an existing, ACTIVE customer
     *   - accountType must be SAVINGS, CURRENT, or FIXED
     *   - accountNumber is auto-generated (never sent by client)
     *   - minimumBalance is set based on accountType
     */
    AccountResponse createAccount(AccountRequest request);

    /**
     * Get all accounts in the system.
     */
    List<AccountResponse> getAllAccounts();

    /**
     * Get a single account by its MongoDB _id.
     * Throws ResourceNotFoundException if not found.
     */
    AccountResponse getAccountById(String id);

    /**
     * ONE-TO-MANY TRAVERSAL:
     * Get all accounts belonging to a specific customer.
     * Throws ResourceNotFoundException if the customer doesn't exist.
     *
     * @param customerId the MongoDB _id of the customer
     * @return list of all accounts owned by that customer
     */
    List<AccountResponse> getAccountsByCustomerId(String customerId);

    /**
     * Update account details.
     * Note: balance is NOT updated here — only via Transaction APIs.
     * Note: accountNumber and customerId cannot be changed.
     */
    AccountResponse updateAccount(String id, AccountRequest request);

    /**
     * Delete an account by ID.
     * In production: only allow deletion if balance is zero.
     */
    void deleteAccount(String id);
}
