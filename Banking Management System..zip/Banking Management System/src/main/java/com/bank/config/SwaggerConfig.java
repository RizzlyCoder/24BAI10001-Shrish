package com.bank.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 SWAGGER UI: http://localhost:8080/swagger-ui/index.html
 */
@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI bankingOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Banking Management System API")
                        .description("""
                                REST API for a Banking Management System.
                                
                                Modules:
                                - Customer Management
                                - Account Management
                                - Transaction Management (Deposit, Withdraw, Transfer)
                                - Branch Management
                                - Employee Management
                                - Joint Account Management
                                """)
                        .version("v1.0.0")
                        .contact(new Contact()
                                .name("Banking System Team")
                                .email("admin@bank.com"))
                        .license(new License()
                                .name("Academic Project License")))
                .servers(List.of(
                        new Server()
                                .url("http://localhost:8080")
                                .description("Local Development Server")
                ));
    }
}
