package com.bank.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request payload for creating or updating a customer")
public class CustomerRequest {

    @NotBlank(message = "Full name is required")
    @Size(min = 2, max = 100, message = "Full name must be between 2 and 100 characters")
    @Schema(description = "Customer's full name", example = "Rahul Sharma")
    private String fullName;

    @NotBlank(message = "Email is required")
    @Email(message = "Email must be a valid email address")
    @Schema(description = "Customer's unique email address", example = "rahul.sharma@example.com")
    private String email;

    @NotBlank(message = "Phone number is required")
    @Pattern(
        regexp = "^[6-9]\\d{9}$",
        message = "Phone must be a valid 10-digit Indian mobile number starting with 6-9"
    )
    @Schema(description = "10-digit mobile number", example = "9876543210")
    private String phone;

    @NotBlank(message = "Address is required")
    @Size(min = 10, max = 300, message = "Address must be between 10 and 300 characters")
    @Schema(description = "Customer's residential address", example = "12, MG Road, Bengaluru, Karnataka - 560001")
    private String address;
}
