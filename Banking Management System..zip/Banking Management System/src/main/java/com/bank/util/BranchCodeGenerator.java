package com.bank.util;

import java.util.concurrent.atomic.AtomicInteger;

public final class BranchCodeGenerator {

    private BranchCodeGenerator() {}

    private static final AtomicInteger counter = new AtomicInteger(0);

   
    public static String generate() {
        int next = counter.incrementAndGet();
        return "BRN" + String.format("%03d", next);
    }
}
