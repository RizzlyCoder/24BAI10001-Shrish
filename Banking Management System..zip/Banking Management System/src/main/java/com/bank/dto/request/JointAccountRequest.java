package com.bank.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.List;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request payload for creating a new joint account")
public class JointAccountRequest {

    
    @NotEmpty(message = "Customer IDs list must not be empty")
    @Size(min = 2, message = "A joint account must have at least 2 customers")
    @Schema(
        description = "List of MongoDB IDs of existing customers (minimum 2)",
        example = "[\"664f1a2b3c4d5e6f7a8b9c0d\", \"664f1a2b3c4d5e6f7a8b9c0e\"]"
    )
    private List<String> customerIds;

    @Schema(
        description = "Optional description or purpose of the joint account",
        example = "Family savings account"
    )
    private String description;
}
