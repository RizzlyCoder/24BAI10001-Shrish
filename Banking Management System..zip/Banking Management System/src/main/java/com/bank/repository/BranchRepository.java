package com.bank.repository;

import com.bank.model.Branch;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface BranchRepository extends MongoRepository<Branch, String> {

    Optional<Branch> findByBranchCode(String branchCode);

    boolean existsByBranchCode(String branchCode);

    boolean existsByEmail(String email);

    List<Branch> findByAddressCity(String city);

    List<Branch> findByAddressState(String state);

    List<Branch> findByStatus(String status);

    List<Branch> findByBranchNameContainingIgnoreCase(String name);

    @Query("{ 'address.city': ?0, 'status': ?1 }")
    List<Branch> findActiveBranchesInCity(String city, String status);
}
