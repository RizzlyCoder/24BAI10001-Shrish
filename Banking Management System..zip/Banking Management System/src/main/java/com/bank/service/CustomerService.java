package com.bank.service;

import com.bank.dto.request.CustomerRequest;
import com.bank.dto.response.CustomerResponse;

import java.util.List;

/**
 * CustomerService — defines the CONTRACT for all customer business operations.
 *
 * WHY AN INTERFACE?
 *   1. DECOUPLING: The controller depends on this interface, not on the
 *      implementation. This means you could swap CustomerServiceImpl for
 *      a different implementation (e.g. MockCustomerService in tests)
 *      without changing a single line in the controller.
 *
 *   2. TESTABILITY: In unit tests, you can mock this interface using
 *      Mockito: when(customerService.getById("1")).thenReturn(...)
 *
 *   3. DEPENDENCY INVERSION PRINCIPLE (SOLID):
 *      "Depend on abstractions, not concretions."
 *      Controller → CustomerService (interface) ← CustomerServiceImpl
 *
 *   4. CLARITY: Just reading this file tells you exactly what the
 *      Customer module can do — no implementation details in the way.
 */
public interface CustomerService {

    /**
     * Create a new customer from the provided request data.
     * Throws DuplicateResourceException if email already exists.
     *
     * @param request validated customer data from the controller
     * @return CustomerResponse with the saved customer including generated ID
     */
    CustomerResponse createCustomer(CustomerRequest request);

    /**
     * Retrieve all customers in the system.
     *
     * @return list of all customers (empty list if none exist, never null)
     */
    List<CustomerResponse> getAllCustomers();

    /**
     * Retrieve a single customer by their MongoDB ID.
     * Throws ResourceNotFoundException if ID doesn't exist.
     *
     * @param id MongoDB ObjectId string (e.g. "664f1a2b3c4d5e6f7a8b9c0d")
     * @return CustomerResponse for the matching customer
     */
    CustomerResponse getCustomerById(String id);

    /**
     * Update an existing customer's details.
     * Throws ResourceNotFoundException if ID doesn't exist.
     * Throws DuplicateResourceException if the new email belongs to another customer.
     *
     * @param id      the customer to update
     * @param request new data to apply
     * @return updated CustomerResponse
     */
    CustomerResponse updateCustomer(String id, CustomerRequest request);

    /**
     * Permanently delete a customer by ID.
     * Throws ResourceNotFoundException if ID doesn't exist.
     *
     * @param id the customer to delete
     */
    void deleteCustomer(String id);
}
