package com.bank.service;

import com.bank.dto.request.BranchRequest;
import com.bank.dto.response.BranchResponse;

import java.util.List;

/**
 * BranchService — contract for all branch operations.
 *
 * Straightforward CRUD interface.
 * No relationship traversal methods here — those live in EmployeeService
 * (Phase 6) where "get all employees for a branch" is defined.
 */
public interface BranchService {

    /**
     * Create a new branch.
     * Branch code is auto-generated — client does NOT send it.
     * Throws DuplicateResourceException if email is already registered.
     */
    BranchResponse createBranch(BranchRequest request);

    /**
     * Get all branches in the system.
     */
    List<BranchResponse> getAllBranches();

    /**
     * Get a single branch by its MongoDB ID.
     * Throws ResourceNotFoundException if not found.
     */
    BranchResponse getBranchById(String id);

    /**
     * Get a branch by its human-readable branch code.
     * Throws ResourceNotFoundException if not found.
     *
     * @param branchCode e.g. "BRN001"
     */
    BranchResponse getBranchByCode(String branchCode);

    /**
     * Update an existing branch's details.
     * Branch code is IMMUTABLE — cannot be changed after creation.
     * Throws ResourceNotFoundException if ID doesn't exist.
     * Throws DuplicateResourceException if new email belongs to another branch.
     */
    BranchResponse updateBranch(String id, BranchRequest request);

    /**
     * Delete a branch by ID.
     * In production: only allowed if branch has no active employees.
     * Throws ResourceNotFoundException if ID doesn't exist.
     */
    void deleteBranch(String id);
}
