package com.bank.service.impl;

import com.bank.dto.request.CustomerRequest;
import com.bank.dto.response.CustomerResponse;
import com.bank.exception.DuplicateResourceException;
import com.bank.exception.ResourceNotFoundException;
import com.bank.model.Customer;
import com.bank.repository.CustomerRepository;
import com.bank.service.CustomerService;
import com.bank.util.AppConstants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * CustomerServiceImpl — the IMPLEMENTATION of CustomerService.
 *
 * WHY @Service?
 *   Marks this as a Spring-managed bean in the Service layer.
 *   Spring will automatically inject it wherever CustomerService is @Autowired.
 *
 * WHY @RequiredArgsConstructor (Lombok)?
 *   Generates a constructor with all 'final' fields as parameters.
 *   This is CONSTRUCTOR INJECTION — the recommended way to inject
 *   dependencies in Spring (vs @Autowired on fields).
 *
 *   The generated constructor looks like:
 *     public CustomerServiceImpl(CustomerRepository customerRepository) {
 *         this.customerRepository = customerRepository;
 *     }
 *
 *   Spring sees this constructor and automatically injects the
 *   CustomerRepository bean when creating CustomerServiceImpl.
 *
 * WHY @Slf4j?
 *   Lombok injects: private static final Logger log = LoggerFactory.getLogger(...)
 *   We use log.info() / log.warn() / log.error() to trace what's happening.
 *   Good logging is essential in production-style code.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

    /** Final fields → constructor injection via @RequiredArgsConstructor */
    private final CustomerRepository customerRepository;

    // ===================================================================
    // CREATE
    // ===================================================================

    /**
     * Business logic for creating a customer:
     *   1. Check if email already exists → throw DuplicateResourceException
     *   2. Build Customer entity from request DTO
     *   3. Save to MongoDB
     *   4. Convert saved entity to response DTO and return
     */
    @Override
    public CustomerResponse createCustomer(CustomerRequest request) {
        log.info("Creating customer with email: {}", request.getEmail());

        // Step 1: Duplicate email check
        if (customerRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException(
                    AppConstants.DUPLICATE_EMAIL + request.getEmail());
        }

        // Step 2: Build the Customer entity using the builder pattern
        Customer customer = Customer.builder()
                .fullName(request.getFullName())
                .email(request.getEmail().toLowerCase().trim()) // normalise email
                .phone(request.getPhone().trim())
                .address(request.getAddress().trim())
                .status("ACTIVE")              // new customers are always ACTIVE
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        // Step 3: Save to MongoDB (repository returns the saved entity with generated ID)
        Customer savedCustomer = customerRepository.save(customer);
        log.info("Customer created successfully with ID: {}", savedCustomer.getId());

        // Step 4: Convert to response DTO and return
        return CustomerResponse.fromEntity(savedCustomer);
    }

    // ===================================================================
    // READ ALL
    // ===================================================================

    /**
     * Fetch all customers from MongoDB and convert each to a response DTO.
     *
     * .stream()           → converts List<Customer> to a Stream
     * .map(...)           → applies CustomerResponse.fromEntity() to each element
     * .collect(...)       → collects results back into a List
     *
     * This is the standard Java Streams pattern for transforming collections.
     */
    @Override
    public List<CustomerResponse> getAllCustomers() {
        log.info("Fetching all customers");

        return customerRepository.findAll()
                .stream()
                .map(CustomerResponse::fromEntity)
                .collect(Collectors.toList());
    }

    // ===================================================================
    // READ BY ID
    // ===================================================================

    /**
     * findById returns Optional<Customer>.
     *
     * .orElseThrow() → if the Optional is empty (customer not found),
     *                  throw ResourceNotFoundException immediately.
     *                  If present, unwrap and return the Customer.
     *
     * This is cleaner than: if (optional.isEmpty()) throw new Exception(...)
     */
    @Override
    public CustomerResponse getCustomerById(String id) {
        log.info("Fetching customer with ID: {}", id);

        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        AppConstants.CUSTOMER_NOT_FOUND + id));

        return CustomerResponse.fromEntity(customer);
    }

    // ===================================================================
    // UPDATE
    // ===================================================================

    /**
     * Business logic for updating a customer:
     *   1. Verify the customer exists → throw 404 if not
     *   2. If email is being changed, check new email isn't taken by ANOTHER customer
     *   3. Apply changes to the existing entity
     *   4. Save and return updated response DTO
     *
     * NOTE: We update the EXISTING entity (not create a new one) so the
     * MongoDB _id stays the same.
     */
    @Override
    public CustomerResponse updateCustomer(String id, CustomerRequest request) {
        log.info("Updating customer with ID: {}", id);

        // Step 1: Find existing customer or throw 404
        Customer existingCustomer = customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        AppConstants.CUSTOMER_NOT_FOUND + id));

        // Step 2: Email uniqueness check — only if the email is being CHANGED
        String newEmail = request.getEmail().toLowerCase().trim();
        if (!existingCustomer.getEmail().equals(newEmail)) {
            // Email is different → check no other customer owns this new email
            if (customerRepository.existsByEmail(newEmail)) {
                throw new DuplicateResourceException(
                        AppConstants.DUPLICATE_EMAIL + newEmail);
            }
        }

        // Step 3: Update the fields on the existing entity
        existingCustomer.setFullName(request.getFullName());
        existingCustomer.setEmail(newEmail);
        existingCustomer.setPhone(request.getPhone().trim());
        existingCustomer.setAddress(request.getAddress().trim());
        existingCustomer.setUpdatedAt(LocalDateTime.now());
        // NOTE: We do NOT touch 'status' here — there should be a separate
        // API to activate/deactivate a customer (single-responsibility).

        // Step 4: Save updated entity and return DTO
        Customer updatedCustomer = customerRepository.save(existingCustomer);
        log.info("Customer updated successfully with ID: {}", updatedCustomer.getId());

        return CustomerResponse.fromEntity(updatedCustomer);
    }

    // ===================================================================
    // DELETE
    // ===================================================================

    /**
     * Business logic for deleting a customer:
     *   1. Verify the customer exists → throw 404 if not
     *   2. Delete by ID
     *
     * In a production system, you would also:
     *   - Check if the customer has active accounts (prevent orphaned accounts)
     *   - Soft-delete (set status = "DELETED") instead of hard-delete
     *   For this academic project, we do a hard delete.
     */
    @Override
    public void deleteCustomer(String id) {
        log.info("Deleting customer with ID: {}", id);

        // Step 1: Confirm existence (deleteById does NOT throw if ID missing)
        if (!customerRepository.existsById(id)) {
            throw new ResourceNotFoundException(
                    AppConstants.CUSTOMER_NOT_FOUND + id);
        }

        // Step 2: Delete the document
        customerRepository.deleteById(id);
        log.info("Customer deleted successfully with ID: {}", id);
    }
}
