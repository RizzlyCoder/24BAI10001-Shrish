package com.bank.controller;

import com.bank.dto.request.BranchRequest;
import com.bank.dto.response.ApiResponse;
import com.bank.dto.response.BranchResponse;
import com.bank.service.BranchService;
import com.bank.util.AppConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/*
   POST   /api/branches                    → Create branch
   GET    /api/branches                    → Get all branches
   GET    /api/branches/{id}               → Get branch by MongoDB ID
   GET    /api/branches/code/{branchCode}  → Get branch by code
   PUT    /api/branches/{id}               → Update branch
   DELETE /api/branches/{id}               → Delete branch

 */

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/branches")
@Tag(name = "Branch Management", description = "APIs for managing bank branches")
public class BranchController {

    private final BranchService branchService;

    
    // POST /api/branches
    
    @PostMapping
    @Operation(
        summary = "Create a new branch",
        description = "Registers a new bank branch. Branch code is auto-generated. " +
                      "The address is a nested object — all address fields are required."
    )
    public ResponseEntity<ApiResponse<BranchResponse>> createBranch(
            @Valid @RequestBody BranchRequest request) {

        log.info("POST /api/branches — creating: {}", request.getBranchName());

        BranchResponse response = branchService.createBranch(request);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success(AppConstants.BRANCH_CREATED, response));
    }

    
    // GET /api/branches
    
    @GetMapping
    @Operation(
        summary = "Get all branches",
        description = "Returns all registered bank branches."
    )
    public ResponseEntity<ApiResponse<List<BranchResponse>>> getAllBranches() {

        log.info("GET /api/branches — fetching all branches");

        List<BranchResponse> branches = branchService.getAllBranches();

        return ResponseEntity.ok(
                ApiResponse.success("Fetched " + branches.size() + " branch(es)", branches));
    }

    
    // GET /api/branches/{id}
    
    @GetMapping("/{id}")
    @Operation(
        summary = "Get branch by ID",
        description = "Fetches a branch using its MongoDB ID."
    )
    public ResponseEntity<ApiResponse<BranchResponse>> getBranchById(
            @Parameter(description = "MongoDB ID of the branch")
            @PathVariable String id) {

        log.info("GET /api/branches/{}", id);

        return ResponseEntity.ok(
                ApiResponse.success("Branch fetched successfully",
                        branchService.getBranchById(id)));
    }

    
    // GET /api/branches/code/{branchCode}
    
    @GetMapping("/code/{branchCode}")
    @Operation(
        summary = "Get branch by branch code",
        description = "Fetches a branch using its human-readable code (e.g. BRN001). " +
                      "This is the preferred lookup method for banking staff."
    )
    public ResponseEntity<ApiResponse<BranchResponse>> getBranchByCode(
            @Parameter(description = "Branch code, e.g. BRN001")
            @PathVariable String branchCode) {

        log.info("GET /api/branches/code/{}", branchCode);

        return ResponseEntity.ok(
                ApiResponse.success("Branch fetched successfully",
                        branchService.getBranchByCode(branchCode)));
    }

    
    // PUT /api/branches/{id}
    
    @PutMapping("/{id}")
    @Operation(
        summary = "Update a branch",
        description = "Updates branch details. Branch code is immutable and cannot be changed."
    )
    public ResponseEntity<ApiResponse<BranchResponse>> updateBranch(
            @Parameter(description = "MongoDB ID of the branch to update")
            @PathVariable String id,
            @Valid @RequestBody BranchRequest request) {

        log.info("PUT /api/branches/{}", id);

        return ResponseEntity.ok(
                ApiResponse.success(AppConstants.BRANCH_UPDATED,
                        branchService.updateBranch(id, request)));
    }

    
    // DELETE /api/branches/{id}
    
    @DeleteMapping("/{id}")
    @Operation(
        summary = "Delete a branch",
        description = "Permanently removes a branch record."
    )
    public ResponseEntity<ApiResponse<Void>> deleteBranch(
            @Parameter(description = "MongoDB ID of the branch to delete")
            @PathVariable String id) {

        log.info("DELETE /api/branches/{}", id);

        branchService.deleteBranch(id);

        return ResponseEntity.ok(
                ApiResponse.success(AppConstants.BRANCH_DELETED));
    }
}
