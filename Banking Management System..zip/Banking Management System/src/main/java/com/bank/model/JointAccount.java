package com.bank.model;

import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "joint_accounts")
public class JointAccount {

    @Id
    private String id;

    
    @Indexed(unique = true)
    @Field("account_number")
    private String accountNumber;

    
    @Field("customer_ids")
    @Builder.Default
    private List<String> customerIds = new ArrayList<>();

    @Field("balance")
    @Builder.Default
    private BigDecimal balance = BigDecimal.ZERO;

    @Field("description")
    private String description;

    @Field("status")
    @Builder.Default
    private String status = "ACTIVE";

    @Field("created_at")
    @CreatedDate
    private LocalDateTime createdAt;

    @Field("updated_at")
    @LastModifiedDate
    private LocalDateTime updatedAt;
}
