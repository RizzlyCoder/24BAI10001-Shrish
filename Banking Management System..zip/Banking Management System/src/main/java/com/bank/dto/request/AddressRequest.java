package com.bank.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Address details for a branch")
public class AddressRequest {

    @NotBlank(message = "Street address is required")
    @Size(min = 5, max = 200, message = "Street must be between 5 and 200 characters")
    @Schema(description = "Street address", example = "12, MG Road")
    private String street;

    @NotBlank(message = "City is required")
    @Size(min = 2, max = 100, message = "City must be between 2 and 100 characters")
    @Schema(description = "City name", example = "Bengaluru")
    private String city;

    @NotBlank(message = "State is required")
    @Size(min = 2, max = 100, message = "State must be between 2 and 100 characters")
    @Schema(description = "State name", example = "Karnataka")
    private String state;

    @NotBlank(message = "Pincode is required")
    @Pattern(
        regexp = "^[1-9][0-9]{5}$",
        message = "Pincode must be a valid 6-digit Indian postal code"
    )
    @Schema(description = "6-digit Indian PIN code", example = "560001")
    private String pincode;
}
