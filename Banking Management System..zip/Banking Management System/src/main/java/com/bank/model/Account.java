package com.bank.model;

import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.math.BigDecimal;
import java.time.LocalDateTime;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "accounts")
public class Account {

    @Id
    private String id;

    
    @Indexed(unique = true)
    @Field("account_number")
    private String accountNumber;

    
    @Field("account_type")
    private String accountType;

    
    @Field("balance")
    @Builder.Default
    private BigDecimal balance = BigDecimal.ZERO;

    
    @Field("customer_id")
    private String customerId;

    
    @Field("status")
    @Builder.Default
    private String status = "ACTIVE";

    
    @Field("minimum_balance")
    @Builder.Default
    private BigDecimal minimumBalance = BigDecimal.ZERO;

    @Field("created_at")
    @CreatedDate
    private LocalDateTime createdAt;

    @Field("updated_at")
    @LastModifiedDate
    private LocalDateTime updatedAt;
}
