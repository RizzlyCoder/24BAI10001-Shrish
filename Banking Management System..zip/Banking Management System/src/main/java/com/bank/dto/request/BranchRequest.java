package com.bank.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request payload for creating or updating a branch")
public class BranchRequest {

    @NotBlank(message = "Branch name is required")
    @Size(min = 3, max = 150, message = "Branch name must be between 3 and 150 characters")
    @Schema(description = "Full name of the branch", example = "MG Road Branch")
    private String branchName;

    
    @NotNull(message = "Address is required")
    @Valid
    @Schema(description = "Branch address details")
    private AddressRequest address;

    @NotBlank(message = "Phone number is required")
    @Schema(description = "Branch landline phone number", example = "08041234567")
    private String phone;

    @NotBlank(message = "Email is required")
    @Email(message = "Email must be a valid email address")
    @Schema(description = "Branch official email address", example = "mgroad@bank.com")
    private String email;
}
