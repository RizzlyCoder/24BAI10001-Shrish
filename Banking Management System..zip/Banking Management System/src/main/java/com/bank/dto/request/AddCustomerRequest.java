package com.bank.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.*;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request payload for adding or removing a customer from a joint account")
public class AddCustomerRequest {

    @NotBlank(message = "Customer ID is required")
    @Schema(
        description = "MongoDB ID of the customer to add or remove",
        example = "664f1a2b3c4d5e6f7a8b9c0f"
    )
    private String customerId;
}
