package com.bank.repository;

import com.bank.model.Account;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface AccountRepository extends MongoRepository<Account, String> {

    List<Account> findByCustomerId(String customerId);

    Optional<Account> findByAccountNumber(String accountNumber);

    
    boolean existsByAccountNumber(String accountNumber);

    List<Account> findByStatus(String status);


    List<Account> findByCustomerIdAndAccountType(String customerId, String accountType);


    long countByCustomerId(String customerId);
}
