package com.bank.dto.response;

import com.bank.model.Address;
import com.bank.model.Branch;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Branch data returned in API responses")
public class BranchResponse {

    @Schema(description = "MongoDB-generated unique ID")
    private String id;

    @Schema(description = "Human-readable branch code", example = "BRN001")
    private String branchCode;

    @Schema(description = "Full name of the branch", example = "MG Road Branch")
    private String branchName;

    @Schema(description = "Branch address (embedded object)")
    private Address address;

    @Schema(description = "Branch phone number", example = "08041234567")
    private String phone;

    @Schema(description = "Branch email address", example = "mgroad@bank.com")
    private String email;

    @Schema(description = "Branch status: ACTIVE, INACTIVE, CLOSED", example = "ACTIVE")
    private String status;

    @Schema(description = "When this branch record was created")
    private LocalDateTime createdAt;

    @Schema(description = "When this branch record was last updated")
    private LocalDateTime updatedAt;

    public static BranchResponse fromEntity(Branch branch) {
        return BranchResponse.builder()
                .id(branch.getId())
                .branchCode(branch.getBranchCode())
                .branchName(branch.getBranchName())
                .address(branch.getAddress())
                .phone(branch.getPhone())
                .email(branch.getEmail())
                .status(branch.getStatus())
                .createdAt(branch.getCreatedAt())
                .updatedAt(branch.getUpdatedAt())
                .build();
    }
}
