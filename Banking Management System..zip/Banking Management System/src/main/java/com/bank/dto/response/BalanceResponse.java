package com.bank.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Account balance information")
public class BalanceResponse {

    @Schema(description = "MongoDB ID of the account")
    private String accountId;

    @Schema(description = "Human-readable account number", example = "SB0000000001")
    private String accountNumber;

    @Schema(description = "Account type", example = "SAVINGS")
    private String accountType;

    @Schema(description = "Current balance in the account", example = "5000.00")
    private BigDecimal currentBalance;

    @Schema(description = "Minimum balance required for this account type", example = "1000.00")
    private BigDecimal minimumBalance;

    @Schema(description = "Available balance (currentBalance - minimumBalance)", example = "4000.00")
    private BigDecimal availableBalance;

    @Schema(description = "Timestamp when this balance was fetched")
    private LocalDateTime asOf;
}
