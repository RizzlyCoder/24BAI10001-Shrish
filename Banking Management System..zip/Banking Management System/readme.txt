Prerequisites:
Java 21
Apache Maven 3.9+
MongoDB 8.x


Run Project:
navigate to the project root directory and open terminal and run the following commands 
mvn clean install -DskipTests
mvn spring-boot:run


After successful startup:
http://localhost:8080/swagger-ui/index.html