package com.bank.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.math.BigDecimal;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request payload for deposit, withdrawal, or transfer operations")
public class TransactionRequest {

    @Schema(description = "Source account MongoDB ID (required for transfer)",
            example = "664f1a2b3c4d5e6f7a8b9c0d")
    private String accountId;        // used as source in transfer; set via @PathVariable in deposit/withdraw

    @Schema(description = "Destination account MongoDB ID (required for transfer only)",
            example = "664f1a2b3c4d5e6f7a8b9c0e")
    private String toAccountId;      // only used for transfer

    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.01", message = "Amount must be greater than zero")
    @Digits(integer = 10, fraction = 2,
            message = "Amount must have at most 10 digits before and 2 digits after the decimal point")
    @Schema(description = "Transaction amount (must be > 0)", example = "5000.00")
    private BigDecimal amount;

    @Schema(description = "Optional note about the transaction", example = "Monthly salary deposit")
    private String description;
}
