package com.bank.controller;

import com.bank.dto.request.TransactionRequest;
import com.bank.dto.response.ApiResponse;
import com.bank.dto.response.BalanceResponse;
import com.bank.dto.response.TransactionResponse;
import com.bank.service.TransactionService;
import com.bank.util.AppConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**

   POST /api/transactions/deposit/{accountId}   → Deposit
   POST /api/transactions/withdraw/{accountId}  → Withdraw
   POST /api/transactions/transfer              → Transfer (both accounts in body)
   GET  /api/transactions/history/{accountId}   → Transaction history
   GET  /api/transactions/balance/{accountId}   → Current balance

 */
@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/transactions")
@Tag(name = "Transaction Management",
     description = "APIs for deposits, withdrawals, transfers and transaction history")
public class TransactionController {

    private final TransactionService transactionService;

    
    // POST /api/transactions/deposit/{accountId}
    
    @PostMapping("/deposit/{accountId}")
    @Operation(
        summary = "Deposit money into an account",
        description = "Adds the specified amount to the account balance. " +
                      "Amount must be greater than zero. " +
                      "Creates a DEPOSIT transaction record."
    )
    public ResponseEntity<ApiResponse<TransactionResponse>> deposit(
            @Parameter(description = "MongoDB ID of the account to deposit into")
            @PathVariable String accountId,
            @Valid @RequestBody TransactionRequest request) {

        log.info("POST /api/transactions/deposit/{}", accountId);

        TransactionResponse response = transactionService.deposit(accountId, request);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success(AppConstants.DEPOSIT_SUCCESS, response));
    }

    
    // POST /api/transactions/withdraw/{accountId}
    
    @PostMapping("/withdraw/{accountId}")
    @Operation(
        summary = "Withdraw money from an account",
        description = "Subtracts the specified amount from the account balance. " +
                      "Withdrawal is blocked if it would bring balance below minimum balance. " +
                      "Creates a WITHDRAWAL transaction record."
    )
    public ResponseEntity<ApiResponse<TransactionResponse>> withdraw(
            @Parameter(description = "MongoDB ID of the account to withdraw from")
            @PathVariable String accountId,
            @Valid @RequestBody TransactionRequest request) {

        log.info("POST /api/transactions/withdraw/{}", accountId);

        TransactionResponse response = transactionService.withdraw(accountId, request);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success(AppConstants.WITHDRAW_SUCCESS, response));
    }

    
    // POST /api/transactions/transfer
    
    @PostMapping("/transfer")
    @Operation(
        summary = "Transfer money between two accounts",
        description = "Moves the specified amount from source account to destination account. " +
                      "Both accounts must be ACTIVE and the source must have sufficient balance. " +
                      "Creates two transaction records: TRANSFER_DEBIT and TRANSFER_CREDIT."
    )
    public ResponseEntity<ApiResponse<List<TransactionResponse>>> transfer(
            @Valid @RequestBody TransactionRequest request) {

        log.info("POST /api/transactions/transfer | from: {} to: {} amount: ₹{}",
                request.getAccountId(), request.getToAccountId(), request.getAmount());

        List<TransactionResponse> responses = transactionService.transfer(request);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success(AppConstants.TRANSFER_SUCCESS, responses));
    }

    
    // GET /api/transactions/history/{accountId}
    
    @GetMapping("/history/{accountId}")
    @Operation(
        summary = "Get transaction history for an account",
        description = "Returns all transactions for the specified account, " +
                      "sorted from newest to oldest. " +
                      "Each record shows the balance after that transaction."
    )
    public ResponseEntity<ApiResponse<List<TransactionResponse>>> getTransactionHistory(
            @Parameter(description = "MongoDB ID of the account")
            @PathVariable String accountId) {

        log.info("GET /api/transactions/history/{}", accountId);

        List<TransactionResponse> history = transactionService.getTransactionHistory(accountId);

        return ResponseEntity.ok(
                ApiResponse.success(
                        "Fetched " + history.size() + " transaction(s)",
                        history));
    }

    
    // GET /api/transactions/balance/{accountId}
    
    @GetMapping("/balance/{accountId}")
    @Operation(
        summary = "Get current balance of an account",
        description = "Returns current balance, minimum balance, and available balance " +
                      "(amount that can be withdrawn without breaching minimum balance)."
    )
    public ResponseEntity<ApiResponse<BalanceResponse>> getBalance(
            @Parameter(description = "MongoDB ID of the account")
            @PathVariable String accountId) {

        log.info("GET /api/transactions/balance/{}", accountId);

        BalanceResponse balance = transactionService.getBalance(accountId);

        return ResponseEntity.ok(
                ApiResponse.success("Balance fetched successfully", balance));
    }
}
