package com.bank.util;

import java.util.concurrent.atomic.AtomicInteger;

public final class EmployeeIdGenerator {

    private EmployeeIdGenerator() {}

    private static final AtomicInteger counter = new AtomicInteger(0);

    
    public static String generate() {
        int next = counter.incrementAndGet();
        return "EMP" + String.format("%04d", next); 
    }
}
