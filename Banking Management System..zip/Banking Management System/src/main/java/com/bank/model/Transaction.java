package com.bank.model;

import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.math.BigDecimal;
import java.time.LocalDateTime;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "transactions")
public class Transaction {

    @Id
    private String id;

    
    @Field("transaction_type")
    private String transactionType;

    
    @Field("amount")
    private BigDecimal amount;

    
    @Indexed
    @Field("account_id")
    private String accountId;

    
    @Field("balance_after")
    private BigDecimal balanceAfter;

    
    @Field("related_account_id")
    private String relatedAccountId;

    
    @Field("description")
    private String description;

    
    @Field("created_at")
    @CreatedDate
    private LocalDateTime createdAt;
}
