package com.bank.controller;

import com.bank.dto.request.EmployeeRequest;
import com.bank.dto.response.ApiResponse;
import com.bank.dto.response.EmployeeResponse;
import com.bank.service.EmployeeService;
import com.bank.util.AppConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**

   POST   /api/employees                         → Create employee
   GET    /api/employees                         → Get all employees
   GET    /api/employees/{id}                    → Get by MongoDB ID
   GET    /api/employees/emp/{employeeId}        → Get by employee ID (EMP0001)
   GET    /api/employees/branch/{branchId}       → Get all employees in a branch
   PUT    /api/employees/{id}                    → Update employee
   DELETE /api/employees/{id}                    → Delete employee
 
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/employees")
@Tag(name = "Employee Management",
     description = "APIs for managing bank employees and branch assignments")
public class EmployeeController {

    private final EmployeeService employeeService;

    
    // POST /api/employees
    
    @PostMapping
    @Operation(
        summary = "Create a new employee",
        description = "Registers a new employee and assigns them to an existing branch. " +
                      "Employee ID is auto-generated. Branch must be ACTIVE."
    )
    public ResponseEntity<ApiResponse<EmployeeResponse>> createEmployee(
            @Valid @RequestBody EmployeeRequest request) {

        log.info("POST /api/employees — creating: {}", request.getFullName());

        EmployeeResponse response = employeeService.createEmployee(request);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success(AppConstants.EMPLOYEE_CREATED, response));
    }

    
    // GET /api/employees
    
    @GetMapping
    @Operation(
        summary = "Get all employees",
        description = "Returns all employees across all branches."
    )
    public ResponseEntity<ApiResponse<List<EmployeeResponse>>> getAllEmployees() {

        log.info("GET /api/employees — fetching all employees");

        List<EmployeeResponse> employees = employeeService.getAllEmployees();

        return ResponseEntity.ok(
                ApiResponse.success("Fetched " + employees.size() + " employee(s)", employees));
    }

    
    // GET /api/employees/{id}
    
    @GetMapping("/{id}")
    @Operation(
        summary = "Get employee by MongoDB ID",
        description = "Fetches an employee using their MongoDB document ID."
    )
    public ResponseEntity<ApiResponse<EmployeeResponse>> getEmployeeById(
            @Parameter(description = "MongoDB ID of the employee")
            @PathVariable String id) {

        log.info("GET /api/employees/{}", id);

        return ResponseEntity.ok(
                ApiResponse.success("Employee fetched successfully",
                        employeeService.getEmployeeById(id)));
    }

    
    // GET /api/employees/emp/{employeeId}
    
    @GetMapping("/emp/{employeeId}")
    @Operation(
        summary = "Get employee by employee ID",
        description = "Fetches an employee using their human-readable employee ID (e.g. EMP0001). " +
                      "Preferred for HR and management queries."
    )
    public ResponseEntity<ApiResponse<EmployeeResponse>> getEmployeeByEmployeeId(
            @Parameter(description = "Human-readable employee ID, e.g. EMP0001")
            @PathVariable String employeeId) {

        log.info("GET /api/employees/emp/{}", employeeId);

        return ResponseEntity.ok(
                ApiResponse.success("Employee fetched successfully",
                        employeeService.getEmployeeByEmployeeId(employeeId)));
    }

    
    // GET /api/employees/branch/{branchId}  ← ONE-TO-MANY ENDPOINT
    
    @GetMapping("/branch/{branchId}")
    @Operation(
        summary = "Get all employees in a branch",
        description = "Returns all employees assigned to a specific branch. " +
                      "This endpoint exposes the Branch → Employee One-to-Many relationship. " +
                      "Returns 404 if the branch does not exist. " +
                      "Returns an empty list if the branch exists but has no employees."
    )
    public ResponseEntity<ApiResponse<List<EmployeeResponse>>> getEmployeesByBranch(
            @Parameter(description = "MongoDB ID of the branch")
            @PathVariable String branchId) {

        log.info("GET /api/employees/branch/{} — fetching employees", branchId);

        List<EmployeeResponse> employees = employeeService.getEmployeesByBranchId(branchId);

        return ResponseEntity.ok(
                ApiResponse.success(
                        "Fetched " + employees.size() + " employee(s) for branch",
                        employees));
    }

    
    // PUT /api/employees/{id}
    
    @PutMapping("/{id}")
    @Operation(
        summary = "Update an employee",
        description = "Updates employee details. Employee ID (EMP0001) is immutable. " +
                      "Changing branchId transfers the employee to another branch — " +
                      "the new branch must be ACTIVE."
    )
    public ResponseEntity<ApiResponse<EmployeeResponse>> updateEmployee(
            @Parameter(description = "MongoDB ID of the employee to update")
            @PathVariable String id,
            @Valid @RequestBody EmployeeRequest request) {

        log.info("PUT /api/employees/{}", id);

        return ResponseEntity.ok(
                ApiResponse.success(AppConstants.EMPLOYEE_UPDATED,
                        employeeService.updateEmployee(id, request)));
    }

    
    // DELETE /api/employees/{id}
    
    @DeleteMapping("/{id}")
    @Operation(
        summary = "Delete an employee",
        description = "Permanently removes an employee record."
    )
    public ResponseEntity<ApiResponse<Void>> deleteEmployee(
            @Parameter(description = "MongoDB ID of the employee to delete")
            @PathVariable String id) {

        log.info("DELETE /api/employees/{}", id);

        employeeService.deleteEmployee(id);

        return ResponseEntity.ok(
                ApiResponse.success(AppConstants.EMPLOYEE_DELETED));
    }
}
