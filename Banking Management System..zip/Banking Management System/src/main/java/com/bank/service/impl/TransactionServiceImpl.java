package com.bank.service.impl;

import com.bank.dto.request.TransactionRequest;
import com.bank.dto.response.BalanceResponse;
import com.bank.dto.response.TransactionResponse;
import com.bank.exception.InsufficientBalanceException;
import com.bank.exception.InvalidOperationException;
import com.bank.exception.ResourceNotFoundException;
import com.bank.model.Account;
import com.bank.model.Transaction;
import com.bank.repository.AccountRepository;
import com.bank.repository.TransactionRepository;
import com.bank.service.TransactionService;
import com.bank.util.AppConstants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * TransactionServiceImpl — the heart of the banking system.
 *
 * This class implements all money movement logic:
 *   - Deposit, Withdrawal, Transfer
 *   - Balance enquiry
 *   - Transaction history
 *
 * KEY DEPENDENCIES:
 *   AccountRepository     → to read and UPDATE account balances
 *   TransactionRepository → to CREATE and READ transaction records
 *
 * BALANCE MATH:
 *   We use BigDecimal.compareTo() — NEVER use == or .equals() to compare
 *   BigDecimal values for greater-than / less-than. Here's why:
 *     new BigDecimal("5000.0").equals(new BigDecimal("5000.00")) → FALSE!
 *     new BigDecimal("5000.0").compareTo(new BigDecimal("5000.00")) → 0 (equal) ✓
 *
 *   compareTo returns:
 *     -1 → left < right
 *      0 → left == right
 *      1 → left > right
 *
 * NOTE ON TRANSACTIONS (ACID):
 *   MongoDB supports multi-document transactions from version 4.0+,
 *   but they require a replica set. For this academic project running
 *   on a standalone MongoDB, we perform operations sequentially.
 *   In production, you'd wrap the transfer logic in a MongoDB session
 *   transaction to guarantee atomicity.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class TransactionServiceImpl implements TransactionService {

    private final AccountRepository     accountRepository;
    private final TransactionRepository transactionRepository;

    // ===================================================================
    // DEPOSIT
    // ===================================================================

    /**
     * DEPOSIT FLOW:
     *   1. Find and validate the account
     *   2. Add amount to balance → save account
     *   3. Record the transaction → save transaction
     *   4. Return TransactionResponse
     */
    @Override
    public TransactionResponse deposit(String accountId, TransactionRequest request) {
        log.info("DEPOSIT ₹{} into account: {}", request.getAmount(), accountId);

        // ── Step 1: Find account ─────────────────────────────────────────
        Account account = findActiveAccount(accountId);

        // ── Step 2: Calculate new balance ───────────────────────────────
        BigDecimal newBalance = account.getBalance().add(request.getAmount());

        // ── Step 3: Update account balance ──────────────────────────────
        account.setBalance(newBalance);
        account.setUpdatedAt(LocalDateTime.now());
        accountRepository.save(account);

        log.info("Account {} new balance after deposit: ₹{}", account.getAccountNumber(), newBalance);

        // ── Step 4: Record the transaction ──────────────────────────────
        Transaction transaction = buildTransaction(
                "DEPOSIT",
                request.getAmount(),
                accountId,
                null,              // no relatedAccountId for deposits
                newBalance,
                request.getDescription() != null
                        ? request.getDescription()
                        : "Deposit of ₹" + request.getAmount()
        );

        Transaction saved = transactionRepository.save(transaction);
        log.info("Transaction recorded: {} | ID: {}", saved.getTransactionType(), saved.getId());

        return TransactionResponse.fromEntity(saved);
    }

    // ===================================================================
    // WITHDRAWAL
    // ===================================================================

    /**
     * WITHDRAWAL FLOW:
     *   1. Find and validate the account
     *   2. Check sufficient balance (balance - amount >= minimumBalance)
     *   3. Subtract amount from balance → save account
     *   4. Record the transaction → save transaction
     *   5. Return TransactionResponse
     */
    @Override
    public TransactionResponse withdraw(String accountId, TransactionRequest request) {
        log.info("WITHDRAWAL ₹{} from account: {}", request.getAmount(), accountId);

        // ── Step 1: Find account ─────────────────────────────────────────
        Account account = findActiveAccount(accountId);

        // ── Step 2: Balance check ────────────────────────────────────────
        // Business Rule: after withdrawal, balance must remain >= minimumBalance
        // availableToWithdraw = currentBalance - minimumBalance
        BigDecimal availableToWithdraw = account.getBalance()
                .subtract(account.getMinimumBalance());

        // compareTo returns -1 if amount > availableToWithdraw (insufficient funds)
        if (request.getAmount().compareTo(availableToWithdraw) > 0) {
            throw new InsufficientBalanceException(
                    AppConstants.INSUFFICIENT_BALANCE + account.getAccountNumber() +
                    ". Current balance: ₹" + account.getBalance() +
                    ", Minimum balance required: ₹" + account.getMinimumBalance() +
                    ", Maximum withdrawable: ₹" + availableToWithdraw);
        }

        // ── Step 3: Calculate and update new balance ─────────────────────
        BigDecimal newBalance = account.getBalance().subtract(request.getAmount());
        account.setBalance(newBalance);
        account.setUpdatedAt(LocalDateTime.now());
        accountRepository.save(account);

        log.info("Account {} new balance after withdrawal: ₹{}", account.getAccountNumber(), newBalance);

        // ── Step 4: Record the transaction ──────────────────────────────
        Transaction transaction = buildTransaction(
                "WITHDRAWAL",
                request.getAmount(),
                accountId,
                null,
                newBalance,
                request.getDescription() != null
                        ? request.getDescription()
                        : "Withdrawal of ₹" + request.getAmount()
        );

        Transaction saved = transactionRepository.save(transaction);
        log.info("Transaction recorded: {} | ID: {}", saved.getTransactionType(), saved.getId());

        return TransactionResponse.fromEntity(saved);
    }

    // ===================================================================
    // TRANSFER
    // ===================================================================

    /**
     * TRANSFER FLOW:
     *   1. Validate: source and destination are different accounts
     *   2. Find and validate BOTH accounts (both must be ACTIVE)
     *   3. Check source has sufficient balance
     *   4. Debit source account → save
     *   5. Credit destination account → save
     *   6. Record TRANSFER_DEBIT transaction for source → save
     *   7. Record TRANSFER_CREDIT transaction for destination → save
     *   8. Return list of [debit transaction, credit transaction]
     *
     * WHY TWO SAVES FOR ACCOUNTS AND TWO FOR TRANSACTIONS?
     *   Each MongoDB document is updated independently. In production with
     *   a replica set, you'd wrap steps 4-7 in a session.withTransaction()
     *   block for ACID guarantees. For this project, sequential saves are fine.
     */
    @Override
    public List<TransactionResponse> transfer(TransactionRequest request) {
        log.info("TRANSFER ₹{} from account: {} to account: {}",
                request.getAmount(), request.getAccountId(), request.getToAccountId());

        // ── Step 1: Validate source ≠ destination ───────────────────────
        if (request.getAccountId().equals(request.getToAccountId())) {
            throw new InvalidOperationException(AppConstants.SAME_ACCOUNT_TRANSFER);
        }

        // ── Step 2: Find both accounts ───────────────────────────────────
        Account sourceAccount = findActiveAccount(request.getAccountId());
        Account destAccount   = findActiveAccount(request.getToAccountId());

        // ── Step 3: Check source balance ─────────────────────────────────
        BigDecimal availableToTransfer = sourceAccount.getBalance()
                .subtract(sourceAccount.getMinimumBalance());

        if (request.getAmount().compareTo(availableToTransfer) > 0) {
            throw new InsufficientBalanceException(
                    AppConstants.INSUFFICIENT_BALANCE + sourceAccount.getAccountNumber() +
                    ". Available for transfer: ₹" + availableToTransfer);
        }

        // ── Step 4: Debit source account ─────────────────────────────────
        BigDecimal sourceNewBalance = sourceAccount.getBalance().subtract(request.getAmount());
        sourceAccount.setBalance(sourceNewBalance);
        sourceAccount.setUpdatedAt(LocalDateTime.now());
        accountRepository.save(sourceAccount);

        // ── Step 5: Credit destination account ───────────────────────────
        BigDecimal destNewBalance = destAccount.getBalance().add(request.getAmount());
        destAccount.setBalance(destNewBalance);
        destAccount.setUpdatedAt(LocalDateTime.now());
        accountRepository.save(destAccount);

        log.info("Transfer complete. Source {} balance: ₹{} | Dest {} balance: ₹{}",
                sourceAccount.getAccountNumber(), sourceNewBalance,
                destAccount.getAccountNumber(), destNewBalance);

        // ── Step 6: Create TRANSFER_DEBIT transaction for source ─────────
        String transferDescription = request.getDescription() != null
                ? request.getDescription()
                : "Transfer of ₹" + request.getAmount();

        Transaction debitTx = buildTransaction(
                "TRANSFER_DEBIT",
                request.getAmount(),
                request.getAccountId(),
                request.getToAccountId(),   // related = destination
                sourceNewBalance,
                "To " + destAccount.getAccountNumber() + " | " + transferDescription
        );
        Transaction savedDebit = transactionRepository.save(debitTx);

        // ── Step 7: Create TRANSFER_CREDIT transaction for destination ────
        Transaction creditTx = buildTransaction(
                "TRANSFER_CREDIT",
                request.getAmount(),
                request.getToAccountId(),
                request.getAccountId(),     // related = source
                destNewBalance,
                "From " + sourceAccount.getAccountNumber() + " | " + transferDescription
        );
        Transaction savedCredit = transactionRepository.save(creditTx);

        log.info("Two transaction records created: DEBIT({}) CREDIT({})",
                savedDebit.getId(), savedCredit.getId());

        // ── Step 8: Return both transaction records ───────────────────────
        return List.of(
                TransactionResponse.fromEntity(savedDebit),
                TransactionResponse.fromEntity(savedCredit)
        );
    }

    // ===================================================================
    // TRANSACTION HISTORY
    // ===================================================================

    /**
     * Returns all transactions for an account, newest-first.
     * This is the Account → Transaction One-to-Many traversal at query time.
     */
    @Override
    public List<TransactionResponse> getTransactionHistory(String accountId) {
        log.info("Fetching transaction history for account: {}", accountId);

        // Verify account exists first
        if (!accountRepository.existsById(accountId)) {
            throw new ResourceNotFoundException(
                    AppConstants.ACCOUNT_NOT_FOUND + accountId);
        }

        return transactionRepository
                .findByAccountIdOrderByCreatedAtDesc(accountId)
                .stream()
                .map(TransactionResponse::fromEntity)
                .collect(Collectors.toList());
    }

    // ===================================================================
    // BALANCE ENQUIRY
    // ===================================================================

    /**
     * Returns the current balance with available balance calculation.
     *
     * availableBalance = currentBalance - minimumBalance
     *
     * This tells the customer: "You can withdraw/transfer at most this amount
     * without breaching your minimum balance requirement."
     */
    @Override
    public BalanceResponse getBalance(String accountId) {
        log.info("Fetching balance for account: {}", accountId);

        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        AppConstants.ACCOUNT_NOT_FOUND + accountId));

        BigDecimal availableBalance = account.getBalance()
                .subtract(account.getMinimumBalance());

        // availableBalance can't go below zero (e.g. if balance < minimumBalance)
        if (availableBalance.compareTo(BigDecimal.ZERO) < 0) {
            availableBalance = BigDecimal.ZERO;
        }

        return BalanceResponse.builder()
                .accountId(account.getId())
                .accountNumber(account.getAccountNumber())
                .accountType(account.getAccountType())
                .currentBalance(account.getBalance())
                .minimumBalance(account.getMinimumBalance())
                .availableBalance(availableBalance)
                .asOf(LocalDateTime.now())
                .build();
    }

    // ===================================================================
    // PRIVATE HELPERS
    // ===================================================================

    /**
     * Finds an account by ID and validates it is ACTIVE.
     * Throws ResourceNotFoundException if not found.
     * Throws InvalidOperationException if account is not ACTIVE.
     *
     * Extracted to a helper because deposit, withdraw, and transfer
     * all need this exact same check — DRY principle.
     */
    private Account findActiveAccount(String accountId) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        AppConstants.ACCOUNT_NOT_FOUND + accountId));

        if (!"ACTIVE".equals(account.getStatus())) {
            throw new InvalidOperationException(
                    "Account " + account.getAccountNumber() +
                    " is not ACTIVE. Current status: " + account.getStatus() +
                    ". Transactions are not allowed on non-active accounts.");
        }

        return account;
    }

    /**
     * Builder helper that constructs a Transaction entity.
     * All transaction creation (deposit, withdraw, transfer x2)
     * goes through this single method — ensures consistent structure.
     *
     * @param type            DEPOSIT / WITHDRAWAL / TRANSFER_DEBIT / TRANSFER_CREDIT
     * @param amount          the transaction amount (always positive)
     * @param accountId       the account this transaction belongs to
     * @param relatedId       the other account (only for transfers, else null)
     * @param balanceAfter    the account balance AFTER this operation
     * @param description     human-readable note
     */
    private Transaction buildTransaction(
            String type,
            BigDecimal amount,
            String accountId,
            String relatedId,
            BigDecimal balanceAfter,
            String description) {

        return Transaction.builder()
                .transactionType(type)
                .amount(amount)
                .accountId(accountId)
                .relatedAccountId(relatedId)
                .balanceAfter(balanceAfter)
                .description(description)
                .createdAt(LocalDateTime.now())
                .build();
    }
}
