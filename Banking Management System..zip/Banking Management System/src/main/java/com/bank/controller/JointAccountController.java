package com.bank.controller;

import com.bank.dto.request.AddCustomerRequest;
import com.bank.dto.request.JointAccountRequest;
import com.bank.dto.response.ApiResponse;
import com.bank.dto.response.JointAccountResponse;
import com.bank.service.JointAccountService;
import com.bank.util.AppConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**

   POST   /api/joint-accounts                              → Create joint account
   GET    /api/joint-accounts                              → Get all joint accounts
   GET    /api/joint-accounts/{id}                         → Get by ID
   GET    /api/joint-accounts/customer/{customerId}        → All joint accounts for a customer
   POST   /api/joint-accounts/{id}/customers               → Add customer to joint account
   DELETE /api/joint-accounts/{id}/customers               → Remove customer from joint account
   DELETE /api/joint-accounts/{id}                         → Delete joint account

 */
@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/joint-accounts")
@Tag(name = "Joint Account Management",
     description = "APIs for managing joint accounts and their customer memberships")
public class JointAccountController {

    private final JointAccountService jointAccountService;

    
    // POST /api/joint-accounts
    
    @PostMapping
    @Operation(
        summary = "Create a new joint account",
        description = "Creates a joint account shared between 2 or more existing customers. " +
                      "All provided customer IDs must refer to existing customers. " +
                      "Account number is auto-generated with 'JT' prefix. " +
                      "Balance starts at zero."
    )
    public ResponseEntity<ApiResponse<JointAccountResponse>> createJointAccount(
            @Valid @RequestBody JointAccountRequest request) {

        log.info("POST /api/joint-accounts — creating with {} customers",
                request.getCustomerIds().size());

        JointAccountResponse response = jointAccountService.createJointAccount(request);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.success(AppConstants.JOINT_ACCOUNT_CREATED, response));
    }

    
    // GET /api/joint-accounts
    
    @GetMapping
    @Operation(
        summary = "Get all joint accounts",
        description = "Returns all joint accounts with enriched customer details " +
                      "(name and email for each account holder)."
    )
    public ResponseEntity<ApiResponse<List<JointAccountResponse>>> getAllJointAccounts() {

        log.info("GET /api/joint-accounts — fetching all");

        List<JointAccountResponse> accounts = jointAccountService.getAllJointAccounts();

        return ResponseEntity.ok(
                ApiResponse.success(
                        "Fetched " + accounts.size() + " joint account(s)", accounts));
    }

    
    // GET /api/joint-accounts/{id}
    
    @GetMapping("/{id}")
    @Operation(
        summary = "Get joint account by ID",
        description = "Returns a single joint account with full customer details for each holder."
    )
    public ResponseEntity<ApiResponse<JointAccountResponse>> getJointAccountById(
            @Parameter(description = "MongoDB ID of the joint account")
            @PathVariable String id) {

        log.info("GET /api/joint-accounts/{}", id);

        return ResponseEntity.ok(
                ApiResponse.success("Joint account fetched successfully",
                        jointAccountService.getJointAccountById(id)));
    }

    
    // GET /api/joint-accounts/customer/{customerId}  ← REVERSE LOOKUP
    
    @GetMapping("/customer/{customerId}")
    @Operation(
        summary = "Get all joint accounts for a customer",
        description = "Returns all joint accounts that a specific customer co-owns. " +
                      "This is the reverse Many-to-Many lookup: " +
                      "MongoDB queries the customer_ids array across all joint account documents."
    )
    public ResponseEntity<ApiResponse<List<JointAccountResponse>>> getJointAccountsByCustomer(
            @Parameter(description = "MongoDB ID of the customer")
            @PathVariable String customerId) {

        log.info("GET /api/joint-accounts/customer/{}", customerId);

        List<JointAccountResponse> accounts =
                jointAccountService.getJointAccountsByCustomerId(customerId);

        return ResponseEntity.ok(
                ApiResponse.success(
                        "Fetched " + accounts.size() + " joint account(s) for customer",
                        accounts));
    }

    
    // POST /api/joint-accounts/{id}/customers  ← ADD MEMBER
    
    @PostMapping("/{id}/customers")
    @Operation(
        summary = "Add a customer to a joint account",
        description = "Adds an existing customer as a new co-owner of the joint account. " +
                      "The customer must exist and must not already be a member. " +
                      "Equivalent to MongoDB $addToSet on the customer_ids array."
    )
    public ResponseEntity<ApiResponse<JointAccountResponse>> addCustomer(
            @Parameter(description = "MongoDB ID of the joint account")
            @PathVariable String id,
            @Valid @RequestBody AddCustomerRequest request) {

        log.info("POST /api/joint-accounts/{}/customers — adding customer: {}",
                id, request.getCustomerId());

        JointAccountResponse response =
                jointAccountService.addCustomerToJointAccount(id, request);

        return ResponseEntity
                .status(HttpStatus.OK)
                .body(ApiResponse.success(AppConstants.CUSTOMER_ADDED, response));
    }

    
    // DELETE /api/joint-accounts/{id}/customers  ← REMOVE MEMBER
    
    @DeleteMapping("/{id}/customers")
    @Operation(
        summary = "Remove a customer from a joint account",
        description = "Removes a customer from the joint account's co-owners. " +
                      "Cannot remove if it would leave fewer than 2 customers. " +
                      "Equivalent to MongoDB $pull on the customer_ids array."
    )
    public ResponseEntity<ApiResponse<JointAccountResponse>> removeCustomer(
            @Parameter(description = "MongoDB ID of the joint account")
            @PathVariable String id,
            @Valid @RequestBody AddCustomerRequest request) {

        log.info("DELETE /api/joint-accounts/{}/customers — removing customer: {}",
                id, request.getCustomerId());

        JointAccountResponse response =
                jointAccountService.removeCustomerFromJointAccount(id, request);

        return ResponseEntity.ok(
                ApiResponse.success(AppConstants.CUSTOMER_REMOVED, response));
    }

    
    // DELETE /api/joint-accounts/{id}
    
    @DeleteMapping("/{id}")
    @Operation(
        summary = "Delete a joint account",
        description = "Permanently deletes a joint account. " +
                      "Balance must be zero before deletion is allowed."
    )
    public ResponseEntity<ApiResponse<Void>> deleteJointAccount(
            @Parameter(description = "MongoDB ID of the joint account to delete")
            @PathVariable String id) {

        log.info("DELETE /api/joint-accounts/{}", id);

        jointAccountService.deleteJointAccount(id);

        return ResponseEntity.ok(
                ApiResponse.success(AppConstants.JOINT_ACCOUNT_DELETED));
    }
}
