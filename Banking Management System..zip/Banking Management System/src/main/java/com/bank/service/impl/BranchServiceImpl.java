package com.bank.service.impl;

import com.bank.dto.request.BranchRequest;
import com.bank.dto.response.BranchResponse;
import com.bank.exception.DuplicateResourceException;
import com.bank.exception.ResourceNotFoundException;
import com.bank.model.Address;
import com.bank.model.Branch;
import com.bank.repository.BranchRepository;
import com.bank.service.BranchService;
import com.bank.util.AppConstants;
import com.bank.util.BranchCodeGenerator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * BranchServiceImpl — implements all branch business logic.
 *
 * KEY RESPONSIBILITIES:
 *   1. Auto-generate branch code on creation
 *   2. Enforce unique email constraint (application-level check)
 *   3. Map AddressRequest → Address model (nested object mapping)
 *   4. Standard CRUD with proper exception handling
 *
 * NESTED OBJECT MAPPING:
 *   When we receive a BranchRequest, the address comes as an AddressRequest.
 *   We must convert it to an Address model before building the Branch entity.
 *   This is done in the private helper mapAddress() below.
 *   This keeps the mapping logic in one place — if Address fields change,
 *   you update only mapAddress().
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BranchServiceImpl implements BranchService {

    private final BranchRepository branchRepository;

    // ===================================================================
    // CREATE
    // ===================================================================

    /**
     * Branch creation flow:
     *   1. Check email uniqueness
     *   2. Generate unique branch code
     *   3. Map AddressRequest → Address model
     *   4. Build Branch entity and save
     *   5. Return BranchResponse
     */
    @Override
    public BranchResponse createBranch(BranchRequest request) {
        log.info("Creating branch: {}", request.getBranchName());

        // ── Step 1: Email uniqueness check ───────────────────────────────
        if (branchRepository.existsByEmail(request.getEmail().toLowerCase().trim())) {
            throw new DuplicateResourceException(
                    "A branch with this email already exists: " + request.getEmail());
        }

        // ── Step 2: Generate unique branch code ──────────────────────────
        String branchCode;
        do {
            branchCode = BranchCodeGenerator.generate();
        } while (branchRepository.existsByBranchCode(branchCode));

        // ── Step 3: Map address DTO → Address model ──────────────────────
        Address address = mapAddress(request);

        // ── Step 4: Build and save Branch entity ─────────────────────────
        Branch branch = Branch.builder()
                .branchCode(branchCode)
                .branchName(request.getBranchName().trim())
                .address(address)
                .phone(request.getPhone().trim())
                .email(request.getEmail().toLowerCase().trim())
                .status("ACTIVE")
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        Branch savedBranch = branchRepository.save(branch);
        log.info("Branch created: {} | Code: {}", savedBranch.getBranchName(), savedBranch.getBranchCode());

        return BranchResponse.fromEntity(savedBranch);
    }

    // ===================================================================
    // READ ALL
    // ===================================================================

    @Override
    public List<BranchResponse> getAllBranches() {
        log.info("Fetching all branches");

        return branchRepository.findAll()
                .stream()
                .map(BranchResponse::fromEntity)
                .collect(Collectors.toList());
    }

    // ===================================================================
    // READ BY ID
    // ===================================================================

    @Override
    public BranchResponse getBranchById(String id) {
        log.info("Fetching branch by ID: {}", id);

        Branch branch = branchRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        AppConstants.BRANCH_NOT_FOUND + id));

        return BranchResponse.fromEntity(branch);
    }

    // ===================================================================
    // READ BY BRANCH CODE
    // ===================================================================

    @Override
    public BranchResponse getBranchByCode(String branchCode) {
        log.info("Fetching branch by code: {}", branchCode);

        Branch branch = branchRepository.findByBranchCode(branchCode.toUpperCase())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Branch not found with code: " + branchCode));

        return BranchResponse.fromEntity(branch);
    }

    // ===================================================================
    // UPDATE
    // ===================================================================

    /**
     * Update rules:
     *   - branchCode is IMMUTABLE (cannot change once assigned)
     *   - email uniqueness is checked only if the email is being changed
     *   - All other fields (name, address, phone) can be freely updated
     */
    @Override
    public BranchResponse updateBranch(String id, BranchRequest request) {
        log.info("Updating branch with ID: {}", id);

        // Step 1: Find existing branch or throw 404
        Branch existingBranch = branchRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        AppConstants.BRANCH_NOT_FOUND + id));

        // Step 2: Email uniqueness check — only if email is CHANGING
        String newEmail = request.getEmail().toLowerCase().trim();
        if (!existingBranch.getEmail().equals(newEmail)) {
            if (branchRepository.existsByEmail(newEmail)) {
                throw new DuplicateResourceException(
                        "A branch with this email already exists: " + newEmail);
            }
        }

        // Step 3: Update all mutable fields
        existingBranch.setBranchName(request.getBranchName().trim());
        existingBranch.setAddress(mapAddress(request));   // re-map nested address
        existingBranch.setPhone(request.getPhone().trim());
        existingBranch.setEmail(newEmail);
        existingBranch.setUpdatedAt(LocalDateTime.now());
        // branchCode is intentionally NOT updated — it is immutable

        Branch updatedBranch = branchRepository.save(existingBranch);
        log.info("Branch updated: {} | Code: {}", updatedBranch.getBranchName(), updatedBranch.getBranchCode());

        return BranchResponse.fromEntity(updatedBranch);
    }

    // ===================================================================
    // DELETE
    // ===================================================================

    /**
     * Delete flow:
     *   1. Verify branch exists
     *   2. Delete document
     *
     * PRODUCTION NOTE:
     *   In a real system, you'd first check if the branch has active
     *   employees (via EmployeeRepository.existsByBranchId(id)) and
     *   block deletion if it does. We keep this simple here since
     *   EmployeeRepository doesn't exist yet — it's added in Phase 6.
     *   Phase 6 will NOT retroactively modify this method; it's mentioned
     *   here for academic awareness only.
     */
    @Override
    public void deleteBranch(String id) {
        log.info("Deleting branch with ID: {}", id);

        if (!branchRepository.existsById(id)) {
            throw new ResourceNotFoundException(
                    AppConstants.BRANCH_NOT_FOUND + id);
        }

        branchRepository.deleteById(id);
        log.info("Branch deleted with ID: {}", id);
    }

    // ===================================================================
    // PRIVATE HELPER
    // ===================================================================

    /**
     * Maps the AddressRequest (DTO) to the Address (model / sub-document).
     *
     * WHY A SEPARATE HELPER?
     *   Both createBranch() and updateBranch() need this mapping.
     *   Extracting it avoids code duplication (DRY principle) and makes
     *   both methods easier to read.
     *
     * @param request the BranchRequest containing the nested AddressRequest
     * @return Address model ready to embed in the Branch document
     */
    private Address mapAddress(BranchRequest request) {
        return Address.builder()
                .street(request.getAddress().getStreet().trim())
                .city(request.getAddress().getCity().trim())
                .state(request.getAddress().getState().trim())
                .pincode(request.getAddress().getPincode().trim())
                .build();
    }
}
