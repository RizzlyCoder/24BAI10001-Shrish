package com.bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class BankingApplication {

    public static void main(String[] args) {
        SpringApplication.run(BankingApplication.class, args);
        System.out.println("""

                ============================================================
                 Banking Management System started successfully!
                 Swagger UI : http://localhost:8080/swagger-ui/index.html
                ============================================================
                """);
    }
}
