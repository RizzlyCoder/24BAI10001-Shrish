package com.bank.model;

import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "employees")
public class Employee {

    @Id
    private String id;

    
    @Indexed(unique = true)
    @Field("employee_id")
    private String employeeId;

    @Field("full_name")
    private String fullName;

    
    @Indexed(unique = true)
    @Field("email")
    private String email;

    @Field("phone")
    private String phone;

    @Field("designation")
    private String designation;

    
    @Field("department")
    private String department;

    
    @Field("salary")
    private BigDecimal salary;

    
    @Field("date_of_joining")
    private LocalDate dateOfJoining;

    
    @Indexed
    @Field("branch_id")
    private String branchId;

    
    @Field("status")
    @Builder.Default
    private String status = "ACTIVE";

    @Field("created_at")
    @CreatedDate
    private LocalDateTime createdAt;

    @Field("updated_at")
    @LastModifiedDate
    private LocalDateTime updatedAt;
}
