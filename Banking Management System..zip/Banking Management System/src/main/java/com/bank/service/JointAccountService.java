package com.bank.service;

import com.bank.dto.request.AddCustomerRequest;
import com.bank.dto.request.JointAccountRequest;
import com.bank.dto.response.JointAccountResponse;

import java.util.List;

/**
 * JointAccountService — contract for all joint account operations.
 *
 * THE MANY-TO-MANY OPERATIONS DEFINED HERE:
 *
 *   addCustomerToJointAccount():
 *     Adds a new customer reference to the customerIds array.
 *     MongoDB operation: $push / $addToSet on the array field.
 *
 *   removeCustomerFromJointAccount():
 *     Removes a customer reference from the customerIds array.
 *     MongoDB operation: $pull on the array field.
 *     Business rule: array can never go below 2 elements.
 *
 *   getJointAccountsByCustomerId():
 *     The "reverse lookup" — find all joint accounts a customer belongs to.
 *     Uses findByCustomerIdsContaining() in the repository.
 *
 * These three methods are the essence of managing a Many-to-Many
 * relationship via array references in MongoDB.
 */
public interface JointAccountService {

    /**
     * Create a new joint account with at least 2 customers.
     * Business rules:
     *   - All customerIds must refer to existing customers
     *   - Minimum 2 customers required
     *   - Account number is auto-generated (JT prefix)
     *   - Balance starts at zero
     */
    JointAccountResponse createJointAccount(JointAccountRequest request);

    /**
     * Get all joint accounts in the system.
     */
    List<JointAccountResponse> getAllJointAccounts();

    /**
     * Get a joint account by its MongoDB _id.
     * Response includes enriched customer details (name + email per holder).
     */
    JointAccountResponse getJointAccountById(String id);

    /**
     * MANY-TO-MANY — REVERSE LOOKUP:
     * Find all joint accounts that contain a specific customer.
     * "Which joint accounts does customer X belong to?"
     *
     * @param customerId MongoDB _id of the customer
     * @return list of all joint accounts the customer co-owns
     */
    List<JointAccountResponse> getJointAccountsByCustomerId(String customerId);

    /**
     * MANY-TO-MANY — ADD MEMBER:
     * Add a new customer to an existing joint account.
     * Business rules:
     *   - Joint account must exist
     *   - Customer must exist
     *   - Customer must NOT already be in the joint account
     *
     * @param jointAccountId MongoDB _id of the joint account
     * @param request        contains the customerId to add
     * @return updated JointAccountResponse with the new customer included
     */
    JointAccountResponse addCustomerToJointAccount(String jointAccountId,
                                                    AddCustomerRequest request);

    /**
     * MANY-TO-MANY — REMOVE MEMBER:
     * Remove a customer from an existing joint account.
     * Business rules:
     *   - Joint account must exist
     *   - Customer must currently be in the joint account
     *   - Removal must not leave fewer than 2 customers
     *     (a joint account with 1 customer is invalid)
     *
     * @param jointAccountId MongoDB _id of the joint account
     * @param request        contains the customerId to remove
     * @return updated JointAccountResponse without the removed customer
     */
    JointAccountResponse removeCustomerFromJointAccount(String jointAccountId,
                                                         AddCustomerRequest request);

    /**
     * Delete a joint account permanently.
     * Business rule: balance must be zero before deletion.
     */
    void deleteJointAccount(String id);
}
