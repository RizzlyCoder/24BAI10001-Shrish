package com.bank.repository;

import com.bank.model.JointAccount;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface JointAccountRepository extends MongoRepository<JointAccount, String> {

    Optional<JointAccount> findByAccountNumber(String accountNumber);

    boolean existsByAccountNumber(String accountNumber);

    List<JointAccount> findByCustomerIdsContaining(String customerId);

    @Query("{ '_id': ?0, 'customer_ids': ?1 }")
    Optional<JointAccount> findByIdAndCustomerIdsContaining(String id, String customerId);

    List<JointAccount> findByStatus(String status);

    long countByCustomerIdsContaining(String customerId);
}
