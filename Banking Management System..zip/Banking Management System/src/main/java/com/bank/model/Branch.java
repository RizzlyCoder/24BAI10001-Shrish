package com.bank.model;

import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDateTime;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "branches")
public class Branch {

    @Id
    private String id;

    
    @Indexed(unique = true)
    @Field("branch_code")
    private String branchCode;

    @Field("branch_name")
    private String branchName;

    
    @Field("address")
    private Address address;

    
    @Field("phone")
    private String phone;

    
    @Indexed(unique = true)
    @Field("email")
    private String email;

    
    @Field("status")
    @Builder.Default
    private String status = "ACTIVE";

    @Field("created_at")
    @CreatedDate
    private LocalDateTime createdAt;

    @Field("updated_at")
    @LastModifiedDate
    private LocalDateTime updatedAt;
}
