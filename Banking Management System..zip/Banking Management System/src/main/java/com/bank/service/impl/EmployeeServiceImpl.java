package com.bank.service.impl;

import com.bank.dto.request.EmployeeRequest;
import com.bank.dto.response.EmployeeResponse;
import com.bank.exception.DuplicateResourceException;
import com.bank.exception.InvalidOperationException;
import com.bank.exception.ResourceNotFoundException;
import com.bank.model.Employee;
import com.bank.repository.BranchRepository;
import com.bank.repository.EmployeeRepository;
import com.bank.service.EmployeeService;
import com.bank.util.AppConstants;
import com.bank.util.EmployeeIdGenerator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * EmployeeServiceImpl — implements all employee business logic.
 *
 * RELATIONSHIP ENFORCEMENT:
 *   We inject BranchRepository to verify that the branchId provided
 *   in EmployeeRequest refers to a real, existing Branch document.
 *
 *   This is the same pattern used throughout the project:
 *     AccountServiceImpl   injects CustomerRepository  → validates customerId
 *     EmployeeServiceImpl  injects BranchRepository    → validates branchId
 *
 *   MongoDB itself doesn't validate foreign references.
 *   The service layer is where we enforce referential integrity.
 *
 * BRANCH STATUS CHECK:
 *   We go one step further here — we check not just that the branch EXISTS,
 *   but also that it is ACTIVE. You shouldn't be able to hire an employee
 *   into a CLOSED or INACTIVE branch. This is a business rule that belongs
 *   in the service layer.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final BranchRepository   branchRepository;  // for relationship validation

    // ===================================================================
    // CREATE
    // ===================================================================

    /**
     * Employee creation flow:
     *   1. Verify branch exists and is ACTIVE
     *   2. Check email uniqueness
     *   3. Generate unique employeeId
     *   4. Build and save Employee entity
     *   5. Return EmployeeResponse
     */
    @Override
    public EmployeeResponse createEmployee(EmployeeRequest request) {
        log.info("Creating employee: {} for branch: {}", request.getFullName(), request.getBranchId());

        // ── Step 1: Branch relationship validation ────────────────────────
        // Business Rule: Employee must be assigned to an existing, ACTIVE branch.
        var branch = branchRepository.findById(request.getBranchId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        AppConstants.BRANCH_NOT_FOUND + request.getBranchId()));

        // Extra check: branch must be ACTIVE to accept new employees
        if (!"ACTIVE".equals(branch.getStatus())) {
            throw new InvalidOperationException(
                    "Cannot assign employee to branch " + branch.getBranchCode() +
                    " — branch status is " + branch.getStatus() +
                    ". Only ACTIVE branches can have employees assigned.");
        }

        // ── Step 2: Email uniqueness check ───────────────────────────────
        if (employeeRepository.existsByEmail(request.getEmail().toLowerCase().trim())) {
            throw new DuplicateResourceException(
                    "An employee with this email already exists: " + request.getEmail());
        }

        // ── Step 3: Generate unique employee ID ──────────────────────────
        String employeeId;
        do {
            employeeId = EmployeeIdGenerator.generate();
        } while (employeeRepository.existsByEmployeeId(employeeId));

        // ── Step 4: Build and save Employee entity ────────────────────────
        Employee employee = Employee.builder()
                .employeeId(employeeId)
                .fullName(request.getFullName().trim())
                .email(request.getEmail().toLowerCase().trim())
                .phone(request.getPhone().trim())
                .designation(request.getDesignation().trim())
                .department(request.getDepartment().trim())
                .salary(request.getSalary())
                .dateOfJoining(request.getDateOfJoining())
                .branchId(request.getBranchId())
                .status("ACTIVE")
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        Employee saved = employeeRepository.save(employee);
        log.info("Employee created: {} | ID: {} | Branch: {}",
                saved.getFullName(), saved.getEmployeeId(), saved.getBranchId());

        return EmployeeResponse.fromEntity(saved);
    }

    // ===================================================================
    // READ ALL
    // ===================================================================

    @Override
    public List<EmployeeResponse> getAllEmployees() {
        log.info("Fetching all employees");

        return employeeRepository.findAll()
                .stream()
                .map(EmployeeResponse::fromEntity)
                .collect(Collectors.toList());
    }

    // ===================================================================
    // READ BY MONGODB ID
    // ===================================================================

    @Override
    public EmployeeResponse getEmployeeById(String id) {
        log.info("Fetching employee by ID: {}", id);

        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        AppConstants.EMPLOYEE_NOT_FOUND + id));

        return EmployeeResponse.fromEntity(employee);
    }

    // ===================================================================
    // READ BY EMPLOYEE ID (human-readable)
    // ===================================================================

    @Override
    public EmployeeResponse getEmployeeByEmployeeId(String employeeId) {
        log.info("Fetching employee by employee ID: {}", employeeId);

        Employee employee = employeeRepository
                .findByEmployeeId(employeeId.toUpperCase())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Employee not found with employee ID: " + employeeId));

        return EmployeeResponse.fromEntity(employee);
    }

    // ===================================================================
    // READ BY BRANCH ID — ONE-TO-MANY TRAVERSAL
    // ===================================================================

    /**
     * Implements the Branch → Employee One-to-Many traversal:
     *
     *   "Get all employees who work at branch X."
     *
     * FLOW:
     *   1. Verify the branch exists (throw 404 if not)
     *   2. Query employees collection: find({ branch_id: branchId })
     *   3. Stream-map results to EmployeeResponse DTOs
     *
     * WHY VERIFY BRANCH FIRST?
     *   If we skip the branch check and return an empty list, the
     *   client doesn't know whether:
     *   (a) The branch exists but has no employees, OR
     *   (b) The branch doesn't exist at all.
     *   These are two very different situations that deserve different
     *   HTTP responses (200 empty list vs 404 not found).
     */
    @Override
    public List<EmployeeResponse> getEmployeesByBranchId(String branchId) {
        log.info("Fetching all employees for branch: {}", branchId);

        // Step 1: Verify branch exists
        if (!branchRepository.existsById(branchId)) {
            throw new ResourceNotFoundException(
                    AppConstants.BRANCH_NOT_FOUND + branchId);
        }

        // Step 2: Fetch employees by branchId reference
        List<Employee> employees = employeeRepository.findByBranchId(branchId);

        log.info("Found {} employee(s) for branch: {}", employees.size(), branchId);

        // Step 3: Map to DTOs
        return employees.stream()
                .map(EmployeeResponse::fromEntity)
                .collect(Collectors.toList());
    }

    // ===================================================================
    // UPDATE
    // ===================================================================

    /**
     * Update rules:
     *   - employeeId (EMP0001) is IMMUTABLE after creation
     *   - email uniqueness checked only if email is changing
     *   - branchId can be changed (employee transfer to another branch)
     *     but new branch must also exist and be ACTIVE
     *   - salary, designation, department, phone, address are freely updatable
     */
    @Override
    public EmployeeResponse updateEmployee(String id, EmployeeRequest request) {
        log.info("Updating employee with ID: {}", id);

        // Step 1: Find existing employee
        Employee existing = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        AppConstants.EMPLOYEE_NOT_FOUND + id));

        // Step 2: If branchId is changing, validate new branch
        if (!existing.getBranchId().equals(request.getBranchId())) {
            log.info("Employee {} transferring from branch {} to {}",
                    existing.getEmployeeId(), existing.getBranchId(), request.getBranchId());

            var newBranch = branchRepository.findById(request.getBranchId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            AppConstants.BRANCH_NOT_FOUND + request.getBranchId()));

            if (!"ACTIVE".equals(newBranch.getStatus())) {
                throw new InvalidOperationException(
                        "Cannot transfer employee to branch " + newBranch.getBranchCode() +
                        " — branch is not ACTIVE.");
            }
        }

        // Step 3: Email uniqueness — only check if email is changing
        String newEmail = request.getEmail().toLowerCase().trim();
        if (!existing.getEmail().equals(newEmail)) {
            if (employeeRepository.existsByEmail(newEmail)) {
                throw new DuplicateResourceException(
                        "An employee with this email already exists: " + newEmail);
            }
        }

        // Step 4: Apply updates (employeeId stays the same — IMMUTABLE)
        existing.setFullName(request.getFullName().trim());
        existing.setEmail(newEmail);
        existing.setPhone(request.getPhone().trim());
        existing.setDesignation(request.getDesignation().trim());
        existing.setDepartment(request.getDepartment().trim());
        existing.setSalary(request.getSalary());
        existing.setDateOfJoining(request.getDateOfJoining());
        existing.setBranchId(request.getBranchId());
        existing.setUpdatedAt(LocalDateTime.now());

        Employee updated = employeeRepository.save(existing);
        log.info("Employee updated: {} | ID: {}", updated.getFullName(), updated.getEmployeeId());

        return EmployeeResponse.fromEntity(updated);
    }

    // ===================================================================
    // DELETE
    // ===================================================================

    @Override
    public void deleteEmployee(String id) {
        log.info("Deleting employee with ID: {}", id);

        if (!employeeRepository.existsById(id)) {
            throw new ResourceNotFoundException(
                    AppConstants.EMPLOYEE_NOT_FOUND + id);
        }

        employeeRepository.deleteById(id);
        log.info("Employee deleted with ID: {}", id);
    }
}
