package com.bank.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Customer data returned in API responses")
public class CustomerResponse {

    @Schema(description = "MongoDB-generated unique ID", example = "664f1a2b3c4d5e6f7a8b9c0d")
    private String id;

    @Schema(description = "Customer's full name", example = "Rahul Sharma")
    private String fullName;

    @Schema(description = "Customer's email address", example = "rahul.sharma@example.com")
    private String email;

    @Schema(description = "Customer's phone number", example = "9876543210")
    private String phone;

    @Schema(description = "Customer's address", example = "12, MG Road, Bengaluru")
    private String address;

    @Schema(description = "Account status: ACTIVE, INACTIVE, SUSPENDED", example = "ACTIVE")
    private String status;

    @Schema(description = "Timestamp when the customer record was created")
    private LocalDateTime createdAt;

    @Schema(description = "Timestamp when the customer record was last updated")
    private LocalDateTime updatedAt;


    public static CustomerResponse fromEntity(com.bank.model.Customer customer) {
        return CustomerResponse.builder()
                .id(customer.getId())
                .fullName(customer.getFullName())
                .email(customer.getEmail())
                .phone(customer.getPhone())
                .address(customer.getAddress())
                .status(customer.getStatus())
                .createdAt(customer.getCreatedAt())
                .updatedAt(customer.getUpdatedAt())
                .build();
    }
}
