package com.bank.dto.response;

import com.bank.model.Employee;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Employee data returned in API responses")
public class EmployeeResponse {

    @Schema(description = "MongoDB-generated unique ID")
    private String id;

    @Schema(description = "Human-readable employee ID", example = "EMP0001")
    private String employeeId;

    @Schema(description = "Employee's full name", example = "Priya Nair")
    private String fullName;

    @Schema(description = "Employee's work email", example = "priya.nair@bank.com")
    private String email;

    @Schema(description = "Employee's phone number", example = "9876543210")
    private String phone;

    @Schema(description = "Job title / role", example = "Branch Manager")
    private String designation;

    @Schema(description = "Department", example = "Management")
    private String department;

    @Schema(description = "Monthly salary in INR", example = "75000.00")
    private BigDecimal salary;

    @Schema(description = "Date of joining", example = "2022-03-15")
    private LocalDate dateOfJoining;

    @Schema(description = "MongoDB ID of the employee's branch")
    private String branchId;

    @Schema(description = "Employment status: ACTIVE, INACTIVE, RESIGNED, RETIRED",
            example = "ACTIVE")
    private String status;

    @Schema(description = "When the employee record was created")
    private LocalDateTime createdAt;

    @Schema(description = "When the employee record was last updated")
    private LocalDateTime updatedAt;

    public static EmployeeResponse fromEntity(Employee employee) {
        return EmployeeResponse.builder()
                .id(employee.getId())
                .employeeId(employee.getEmployeeId())
                .fullName(employee.getFullName())
                .email(employee.getEmail())
                .phone(employee.getPhone())
                .designation(employee.getDesignation())
                .department(employee.getDepartment())
                .salary(employee.getSalary())
                .dateOfJoining(employee.getDateOfJoining())
                .branchId(employee.getBranchId())
                .status(employee.getStatus())
                .createdAt(employee.getCreatedAt())
                .updatedAt(employee.getUpdatedAt())
                .build();
    }
}
