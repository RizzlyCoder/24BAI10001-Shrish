package com.bank.repository;

import com.bank.model.Transaction;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TransactionRepository extends MongoRepository<Transaction, String> {

    List<Transaction> findByAccountIdOrderByCreatedAtDesc(String accountId);

    List<Transaction> findByAccountIdAndCreatedAtBetweenOrderByCreatedAtDesc(
            String accountId,
            LocalDateTime startDate,
            LocalDateTime endDate);


    List<Transaction> findByAccountIdAndTransactionTypeOrderByCreatedAtDesc(
            String accountId,
            String transactionType);

    long countByAccountId(String accountId);

    List<Transaction> findByRelatedAccountIdOrderByCreatedAtDesc(String relatedAccountId);
}
