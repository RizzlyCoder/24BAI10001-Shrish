package com.bank.model;

import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDateTime;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "customers")
public class Customer {

    
    @Id
    private String id;

    
    @Field("full_name")
    private String fullName;

    
    @Indexed(unique = true)
    @Field("email")
    private String email;

    
    @Field("phone")
    private String phone;

    
    @Field("address")
    private String address;

    
    @Field("status")
    @Builder.Default
    private String status = "ACTIVE"; 

    
    @Field("created_at")
    @CreatedDate
    private LocalDateTime createdAt;

    
    @Field("updated_at")
    @LastModifiedDate
    private LocalDateTime updatedAt;
}
