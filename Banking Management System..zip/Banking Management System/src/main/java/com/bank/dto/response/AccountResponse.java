package com.bank.dto.response;

import com.bank.model.Account;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Account data returned in API responses")
public class AccountResponse {

    @Schema(description = "MongoDB-generated unique ID of the account")
    private String id;

    @Schema(description = "System-generated unique account number", example = "SB0000000001")
    private String accountNumber;

    @Schema(description = "Type of account", example = "SAVINGS")
    private String accountType;

    @Schema(description = "Current account balance", example = "5000.00")
    private BigDecimal balance;

    @Schema(description = "Minimum balance required for this account type", example = "1000.00")
    private BigDecimal minimumBalance;

    @Schema(description = "MongoDB ID of the owning customer")
    private String customerId;

    @Schema(description = "Account status: ACTIVE, INACTIVE, CLOSED, FROZEN", example = "ACTIVE")
    private String status;

    @Schema(description = "When the account was created")
    private LocalDateTime createdAt;

    @Schema(description = "When the account was last updated")
    private LocalDateTime updatedAt;

    
    public static AccountResponse fromEntity(Account account) {
        return AccountResponse.builder()
                .id(account.getId())
                .accountNumber(account.getAccountNumber())
                .accountType(account.getAccountType())
                .balance(account.getBalance())
                .minimumBalance(account.getMinimumBalance())
                .customerId(account.getCustomerId())
                .status(account.getStatus())
                .createdAt(account.getCreatedAt())
                .updatedAt(account.getUpdatedAt())
                .build();
    }
}
