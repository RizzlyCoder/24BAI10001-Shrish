package com.bank.service;

import com.bank.dto.request.TransactionRequest;
import com.bank.dto.response.BalanceResponse;
import com.bank.dto.response.TransactionResponse;

import java.util.List;

/**
 * TransactionService — contract for all financial operations.
 *
 * IMPORTANT DESIGN DECISIONS REFLECTED HERE:
 *
 * 1. deposit / withdraw take (accountId, request):
 *    accountId comes from the URL path variable (@PathVariable in controller).
 *    This is cleaner than putting accountId in the request body for
 *    single-account operations (deposit and withdraw affect ONE account).
 *
 * 2. transfer takes just (request):
 *    Transfer involves TWO accounts, so both accountId (source) and
 *    toAccountId (destination) come from the request body.
 *
 * 3. getTransactionHistory returns List<TransactionResponse>:
 *    Ordered newest-first (handled in repository query).
 *
 * 4. getBalance returns BalanceResponse (not AccountResponse):
 *    Focused DTO — only balance-related fields.
 */
public interface TransactionService {

    /**
     * Deposit money into an account.
     * Business rules:
     *   - amount must be > 0
     *   - account must exist and be ACTIVE
     *   - balance increases by amount
     *   - one Transaction(DEPOSIT) document is created
     *
     * @param accountId MongoDB _id of the account to deposit into
     * @param request   contains amount and optional description
     * @return the created Transaction record
     */
    TransactionResponse deposit(String accountId, TransactionRequest request);

    /**
     * Withdraw money from an account.
     * Business rules:
     *   - amount must be > 0
     *   - account must exist and be ACTIVE
     *   - (balance - amount) must be >= minimumBalance
     *   - balance decreases by amount
     *   - one Transaction(WITHDRAWAL) document is created
     *
     * @param accountId MongoDB _id of the account to withdraw from
     * @param request   contains amount and optional description
     * @return the created Transaction record
     */
    TransactionResponse withdraw(String accountId, TransactionRequest request);

    /**
     * Transfer money between two accounts.
     * Business rules:
     *   - amount must be > 0
     *   - source and destination must be different accounts
     *   - both accounts must exist and be ACTIVE
     *   - source (balance - amount) must be >= source minimumBalance
     *   - source balance decreases, destination balance increases
     *   - TWO Transaction documents are created:
     *       one TRANSFER_DEBIT for source
     *       one TRANSFER_CREDIT for destination
     *
     * @param request contains accountId (source), toAccountId (dest), amount
     * @return list of two Transaction records [debit, credit]
     */
    List<TransactionResponse> transfer(TransactionRequest request);

    /**
     * Get full transaction history for an account, newest-first.
     * Throws ResourceNotFoundException if account doesn't exist.
     *
     * @param accountId MongoDB _id of the account
     * @return all transactions for that account, ordered newest-first
     */
    List<TransactionResponse> getTransactionHistory(String accountId);

    /**
     * Get current balance of an account with available balance calculation.
     * Throws ResourceNotFoundException if account doesn't exist.
     *
     * @param accountId MongoDB _id of the account
     * @return BalanceResponse with current, minimum, and available balance
     */
    BalanceResponse getBalance(String accountId);
}
