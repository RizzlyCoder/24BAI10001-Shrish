package com.bank.model;

import lombok.*;
import org.springframework.data.mongodb.core.mapping.Field;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Address {

    @Field("street")
    private String street;

    @Field("city")
    private String city;

    @Field("state")
    private String state;

    
    @Field("pincode")
    private String pincode;

    
    public String toDisplayString() {
        return street + ", " + city + ", " + state + " - " + pincode;
    }
}
