package com.bank.service;

import com.bank.dto.request.EmployeeRequest;
import com.bank.dto.response.EmployeeResponse;

import java.util.List;

/**
 * EmployeeService — contract for all employee business operations.
 *
 * RELATIONSHIP METHODS:
 *   getEmployeesByBranchId() → One-to-Many traversal: Branch → Employees
 *   This is the read-side of the Branch → Employee relationship.
 *
 * PATTERN CONSISTENCY:
 *   Notice this mirrors AccountService exactly in structure:
 *     AccountService.getAccountsByCustomerId()  → Customer → Accounts
 *     EmployeeService.getEmployeesByBranchId()  → Branch   → Employees
 *
 *   The same design pattern applies to both One-to-Many relationships
 *   in this project. Once you understand one, you understand both.
 */
public interface EmployeeService {

    /**
     * Create a new employee and assign them to an existing branch.
     * Business rules:
     *   - branchId must refer to an existing, ACTIVE branch
     *   - email must be unique across all employees
     *   - employeeId is auto-generated
     *   - dateOfJoining cannot be in the future
     */
    EmployeeResponse createEmployee(EmployeeRequest request);

    /**
     * Get all employees across all branches.
     */
    List<EmployeeResponse> getAllEmployees();

    /**
     * Get a single employee by MongoDB _id.
     * Throws ResourceNotFoundException if not found.
     */
    EmployeeResponse getEmployeeById(String id);

    /**
     * Get an employee by their human-readable employeeId (e.g. "EMP0001").
     * Throws ResourceNotFoundException if not found.
     */
    EmployeeResponse getEmployeeByEmployeeId(String employeeId);

    /**
     * ONE-TO-MANY TRAVERSAL: Branch → Employees
     * Get all employees assigned to a specific branch.
     * Throws ResourceNotFoundException if branch doesn't exist.
     *
     * @param branchId MongoDB _id of the branch
     * @return list of all employees in that branch
     */
    List<EmployeeResponse> getEmployeesByBranchId(String branchId);

    /**
     * Update an existing employee's details.
     * employeeId is IMMUTABLE — cannot be changed after creation.
     * Throws ResourceNotFoundException if ID doesn't exist.
     * Throws DuplicateResourceException if new email belongs to another employee.
     */
    EmployeeResponse updateEmployee(String id, EmployeeRequest request);

    /**
     * Delete an employee record by MongoDB _id.
     * Throws ResourceNotFoundException if not found.
     */
    void deleteEmployee(String id);
}
